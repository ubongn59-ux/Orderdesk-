package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AddShoppingCart
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.People
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.CustomerEntity
import com.example.data.local.OrderEntity
import com.example.data.local.OrderStatus
import com.example.ui.theme.DangerRed
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.WhatsAppGreen
import com.example.util.Formatters
import com.example.util.WhatsAppHelper
import kotlinx.coroutines.flow.Flow

@Composable
fun CustomersScreen(
    customers: List<CustomerEntity>,
    allOrders: List<OrderEntity>,
    currencySymbol: String,
    businessName: String,
    openEditorTrigger: Boolean,
    onConsumeEditorTrigger: () -> Unit,
    observeCustomerOrders: (String) -> Flow<List<OrderEntity>>,
    onSaveCustomer: (
        existingId: String?,
        name: String,
        phone: String,
        email: String,
        address: String,
        notes: String,
        onDone: () -> Unit
    ) -> Unit,
    onDeleteCustomer: (String) -> Unit,
    onCreateOrderForCustomer: (CustomerEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var editingCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var showEditorSheet by remember { mutableStateOf(false) }
    var detailCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var deleteCandidate by remember { mutableStateOf<CustomerEntity?>(null) }

    if (openEditorTrigger) {
        editingCustomer = null
        showEditorSheet = true
        onConsumeEditorTrigger()
    }

    val filteredCustomers = remember(customers, searchQuery) {
        customers.filter { c ->
            searchQuery.isBlank() ||
                c.name.contains(searchQuery, ignoreCase = true) ||
                c.phone.contains(searchQuery, ignoreCase = true) ||
                c.email.contains(searchQuery, ignoreCase = true)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingCustomer = null
                    showEditorSheet = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_customer_fab")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Add customer")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search customers by name, phone, or email") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true,
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .testTag("customers_search_input")
            )

            if (filteredCustomers.isEmpty()) {
                Box(modifier = Modifier.padding(16.dp)) {
                    EmptyStateCard(
                        icon = Icons.Rounded.People,
                        title = if (customers.isEmpty()) "No customers saved yet" else "No matching customers",
                        subtitle = "Save customer phone numbers and emails to track purchase history and send WhatsApp receipts.",
                        actionLabel = if (customers.isEmpty()) "Add Customer" else null,
                        onAction = if (customers.isEmpty()) {
                            { editingCustomer = null; showEditorSheet = true }
                        } else null
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredCustomers, key = { it.id }) { customer ->
                        val custOrders = allOrders.filter {
                            it.customerId == customer.id && it.statusEnum != OrderStatus.CANCELLED
                        }
                        val totalSpent = custOrders.sumOf { it.totalAmount }
                        CustomerItemCard(
                            customer = customer,
                            orderCount = custOrders.size,
                            totalSpent = totalSpent,
                            currencySymbol = currencySymbol,
                            onClick = { detailCustomer = customer },
                            onEdit = {
                                editingCustomer = customer
                                showEditorSheet = true
                            },
                            onDelete = { deleteCandidate = customer }
                        )
                    }
                }
            }
        }
    }

    if (showEditorSheet) {
        CustomerEditorSheet(
            initial = editingCustomer,
            onDismiss = { showEditorSheet = false },
            onSave = { name, phone, email, address, notes ->
                onSaveCustomer(editingCustomer?.id, name, phone, email, address, notes) {
                    showEditorSheet = false
                }
            }
        )
    }

    detailCustomer?.let { customer ->
        val history by observeCustomerOrders(customer.id).collectAsStateWithLifecycle(initialValue = emptyList())
        CustomerDetailSheet(
            customer = customer,
            orders = history,
            currencySymbol = currencySymbol,
            businessName = businessName,
            onDismiss = { detailCustomer = null },
            onCreateOrder = {
                detailCustomer = null
                onCreateOrderForCustomer(customer)
            },
            onEdit = {
                detailCustomer = null
                editingCustomer = customer
                showEditorSheet = true
            }
        )
    }

    deleteCandidate?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteCandidate = null },
            title = { Text("Delete Customer?") },
            text = { Text("Remove ${target.name} from your customer directory?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteCustomer(target.id)
                        deleteCandidate = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DangerRed)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteCandidate = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun CustomerItemCard(
    customer: CustomerEntity,
    orderCount: Int,
    totalSpent: Double,
    currencySymbol: String,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val initials = customer.name.trim()
        .split(" ")
        .filter { it.isNotBlank() }
        .take(2)
        .joinToString("") { it.first().uppercaseChar().toString() }
        .ifEmpty { "C" }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("customer_card_${customer.id}"),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = initials,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = customer.name,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = Formatters.formatNigerianPhone(customer.phone),
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMono),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "$orderCount orders • ${Formatters.formatCurrency(totalSpent, currencySymbol)} spent",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            IconButton(onClick = onEdit, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Rounded.Edit, contentDescription = "Edit ${customer.name}")
            }
            IconButton(onClick = onDelete, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Rounded.Delete, contentDescription = "Delete ${customer.name}", tint = DangerRed)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CustomerEditorSheet(
    initial: CustomerEntity?,
    onDismiss: () -> Unit,
    onSave: (name: String, phone: String, email: String, address: String, notes: String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var phone by remember { mutableStateOf(initial?.phone ?: "") }
    var email by remember { mutableStateOf(initial?.email ?: "") }
    var address by remember { mutableStateOf(initial?.address ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = if (initial == null) "Add Customer" else "Edit Customer",
                style = MaterialTheme.typography.headlineSmall
            )
            if (error != null) {
                Text(error!!, color = DangerRed, style = MaterialTheme.typography.bodySmall)
            }
            OutlinedTextField(
                value = name,
                onValueChange = { name = it; error = null },
                label = { Text("Customer Name *") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("customer_name_input")
            )
            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it; error = null },
                label = { Text("Phone Number (e.g. 0803... or +234...) *") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("customer_phone_input")
            )
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email Address (Optional)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("customer_email_input")
            )
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Delivery Address (Optional)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes (Optional)") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    when {
                        name.isBlank() -> error = "Please enter customer name."
                        !Formatters.isValidNigerianOrIntlPhone(phone) -> error = "Enter a valid Nigerian or international phone number."
                        else -> onSave(name, phone, email, address, notes)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_customer_button")
            ) {
                Text(if (initial == null) "Save Customer" else "Update Customer")
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CustomerDetailSheet(
    customer: CustomerEntity,
    orders: List<OrderEntity>,
    currencySymbol: String,
    businessName: String,
    onDismiss: () -> Unit,
    onCreateOrder: () -> Unit,
    onEdit: () -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val validOrders = orders.filter { it.statusEnum != OrderStatus.CANCELLED }
    val totalSpent = validOrders.sumOf { it.totalAmount }
    val outstanding = validOrders.sumOf { it.outstandingBalance }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(customer.name, style = MaterialTheme.typography.headlineSmall)
                    Text(
                        Formatters.formatNigerianPhone(customer.phone),
                        style = MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMono),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TextButton(onClick = onEdit) { Text("Edit") }
            }

            if (customer.email.isNotBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Email, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(customer.email, style = MaterialTheme.typography.bodyMedium)
                }
            }
            if (customer.address.isNotBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(customer.address, style = MaterialTheme.typography.bodyMedium)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                KpiMetricCard(
                    title = "Total Spent",
                    value = Formatters.formatCurrency(totalSpent, currencySymbol),
                    subtitle = "${orders.size} total orders",
                    icon = Icons.Rounded.Phone,
                    accentColor = MaterialTheme.colorScheme.primary,
                    useMonoFont = true,
                    modifier = Modifier.weight(1f)
                )
                KpiMetricCard(
                    title = "Balance Due",
                    value = Formatters.formatCurrency(outstanding, currencySymbol),
                    subtitle = if (outstanding > 0) "Unpaid balance" else "All settled",
                    icon = Icons.Rounded.Email,
                    accentColor = if (outstanding > 0) DangerRed else Color(0xFF15803D),
                    useMonoFont = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onCreateOrder,
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Icon(Icons.Rounded.AddShoppingCart, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Order")
                }
                OutlinedButton(
                    onClick = {
                        WhatsAppHelper.sendViaWhatsApp(
                            context = context,
                            rawPhone = customer.phone,
                            message = "Hello ${customer.name}, greetings from $businessName! How may we assist you today?"
                        )
                    },
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Icon(Icons.Rounded.Chat, contentDescription = null, tint = WhatsAppGreen, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("WhatsApp", color = WhatsAppGreen)
                }
            }

            HorizontalDivider()
            Text("Purchase History", style = MaterialTheme.typography.titleMedium)

            if (orders.isEmpty()) {
                Text(
                    "No orders placed by this customer yet.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                orders.forEach { order ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(order.orderNumber, style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMono))
                                Text(Formatters.formatDateTime(order.createdAt), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(Formatters.formatCurrency(order.totalAmount, currencySymbol), style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMono))
                                Spacer(modifier = Modifier.height(4.dp))
                                PaymentStatusBadge(order.paymentStatusEnum)
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
