package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.AuthResult
import com.example.data.repository.OrderDeskRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AuthScreenMode {
    LOGIN,
    REGISTER,
    OTP_VERIFY,
    FORGOT_EMAIL,
    FORGOT_RESET
}

data class AuthUiState(
    val mode: AuthScreenMode = AuthScreenMode.LOGIN,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val infoMessage: String? = null,
    val pendingEmail: String = "",
    val issuedOtpPreview: String? = null,
    val resendCooldownSeconds: Int = 0
)

class AuthViewModel(
    private val repository: OrderDeskRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private var cooldownJob: Job? = null

    fun switchMode(mode: AuthScreenMode) {
        _uiState.update {
            it.copy(
                mode = mode,
                errorMessage = null,
                infoMessage = null,
                issuedOtpPreview = if (mode == AuthScreenMode.LOGIN || mode == AuthScreenMode.REGISTER) null else it.issuedOtpPreview
            )
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(errorMessage = null, infoMessage = null) }
    }

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter both email and password.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, infoMessage = null) }
            when (val res = repository.login(email, password)) {
                is AuthResult.Authenticated -> {
                    _uiState.update { it.copy(isLoading = false) }
                }
                is AuthResult.RequiresOtpVerification -> {
                    startCooldown()
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            mode = AuthScreenMode.OTP_VERIFY,
                            pendingEmail = res.email,
                            issuedOtpPreview = res.otpCode,
                            infoMessage = "Please verify your email with the 6-digit OTP code before signing in."
                        )
                    }
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
                }
            }
        }
    }

    fun register(fullName: String, email: String, businessName: String, password: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, infoMessage = null) }
            when (val res = repository.registerUser(fullName, email, businessName, password)) {
                is AuthResult.RequiresOtpVerification -> {
                    startCooldown()
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            mode = AuthScreenMode.OTP_VERIFY,
                            pendingEmail = res.email,
                            issuedOtpPreview = res.otpCode,
                            infoMessage = "We sent a 6-digit verification code to ${res.email}."
                        )
                    }
                }
                is AuthResult.Authenticated -> {
                    _uiState.update { it.copy(isLoading = false) }
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
                }
            }
        }
    }

    fun verifyOtp(code: String) {
        val email = _uiState.value.pendingEmail
        if (code.trim().length != 6) {
            _uiState.update { it.copy(errorMessage = "Enter the 6-digit verification code.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val res = repository.verifyRegistrationOtp(email, code)) {
                is AuthResult.Authenticated -> {
                    _uiState.update { it.copy(isLoading = false, issuedOtpPreview = null) }
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = res.message) }
                }
                is AuthResult.RequiresOtpVerification -> {
                    _uiState.update { it.copy(isLoading = false) }
                }
            }
        }
    }

    fun resendOtp() {
        if (_uiState.value.resendCooldownSeconds > 0) return
        val email = _uiState.value.pendingEmail
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            val result = repository.resendRegistrationOtp(email)
            result.onSuccess { newCode ->
                startCooldown()
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        issuedOtpPreview = newCode,
                        infoMessage = "A new verification code was issued for $email."
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(isLoading = false, errorMessage = err.message ?: "Unable to resend OTP.")
                }
            }
        }
    }

    fun requestPasswordReset(email: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, infoMessage = null) }
            val res = repository.requestPasswordReset(email)
            res.onSuccess { dispatch ->
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        mode = AuthScreenMode.FORGOT_RESET,
                        pendingEmail = dispatch.email,
                        issuedOtpPreview = dispatch.otpCode,
                        infoMessage = "Enter the 6-digit reset code and choose a new password."
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(isLoading = false, errorMessage = err.message ?: "Failed to initiate reset.")
                }
            }
        }
    }

    fun resetPassword(otp: String, newPassword: String) {
        val email = _uiState.value.pendingEmail
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            val res = repository.resetPasswordWithOtp(email, otp, newPassword)
            res.onSuccess {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        mode = AuthScreenMode.LOGIN,
                        issuedOtpPreview = null,
                        infoMessage = "Password reset successful. Sign in with your new password."
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(isLoading = false, errorMessage = err.message ?: "Password reset failed.")
                }
            }
        }
    }

    private fun startCooldown() {
        cooldownJob?.cancel()
        cooldownJob = viewModelScope.launch {
            for (sec in 30 downTo 0) {
                _uiState.update { it.copy(resendCooldownSeconds = sec) }
                if (sec > 0) delay(1000L)
            }
        }
    }
}
