package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.OrderEntity
import com.example.data.local.OrderStatus
import com.example.data.local.PaymentEntity
import com.example.data.local.PaymentMethod
import com.example.data.local.PaymentStatus
import com.example.ui.theme.DangerRed
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.SkySecondary
import com.example.ui.theme.SuccessGreen
import com.example.util.Formatters

@Composable
fun PaymentsScreen(
    payments: List<PaymentEntity>,
    orders: List<OrderEntity>,
    currencySymbol: String,
    onRecordPayment: (orderId: String, amount: Double, method: PaymentMethod, reference: String, notes: String, onDone: () -> Unit) -> Unit,
    onOpenOrder: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Transactions, 1 = Balances Due
    var methodFilter by remember { mutableStateOf<PaymentMethod?>(null) }
    var paymentTargetOrder by remember { mutableStateOf<OrderEntity?>(null) }

    val activeOrders = remember(orders) {
        orders.filter { it.statusEnum != OrderStatus.CANCELLED }
    }
    val unpaidOrPartialOrders = remember(activeOrders) {
        activeOrders.filter { it.paymentStatusEnum != PaymentStatus.PAID && it.outstandingBalance > 0.0 }
    }
    val totalCollected = remember(payments) { payments.sumOf { it.amount } }
    val totalOutstanding = remember(unpaidOrPartialOrders) { unpaidOrPartialOrders.sumOf { it.outstandingBalance } }
    val cashTotal = remember(payments) { payments.filter { it.methodEnum == PaymentMethod.CASH }.sumOf { it.amount } }
    val transferTotal = remember(payments) { payments.filter { it.methodEnum == PaymentMethod.BANK_TRANSFER }.sumOf { it.amount } }

    val filteredPayments = remember(payments, methodFilter) {
        if (methodFilter == null) payments else payments.filter { it.methodEnum == methodFilter }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            if (unpaidOrPartialOrders.isNotEmpty()) {
                FloatingActionButton(
                    onClick = { paymentTargetOrder = unpaidOrPartialOrders.first() },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("record_payment_fab")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = "Record payment")
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    KpiMetricCard(
                        title = "Total Collected",
                        value = Formatters.formatCurrency(totalCollected, currencySymbol),
                        subtitle = "${payments.size} payments",
                        icon = Icons.Rounded.AccountBalanceWallet,
                        accentColor = SuccessGreen,
                        useMonoFont = true,
                        modifier = Modifier.weight(1f)
                    )
                    KpiMetricCard(
                        title = "Outstanding Due",
                        value = Formatters.formatCurrency(totalOutstanding, currencySymbol),
                        subtitle = "${unpaidOrPartialOrders.size} open orders",
                        icon = Icons.Rounded.WarningAmber,
                        accentColor = if (totalOutstanding > 0) DangerRed else SuccessGreen,
                        useMonoFont = true,
                        modifier = Modifier.weight(1f),
                        onClick = { selectedTab = 1 }
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    KpiMetricCard(
                        title = "Cash Payments",
                        value = Formatters.formatCurrency(cashTotal, currencySymbol),
                        subtitle = "Cash drawer",
                        icon = Icons.Rounded.Payments,
                        accentColor = MaterialTheme.colorScheme.primary,
                        useMonoFont = true,
                        modifier = Modifier.weight(1f)
                    )
                    KpiMetricCard(
                        title = "Bank Transfers",
                        value = Formatters.formatCurrency(transferTotal, currencySymbol),
                        subtitle = "Direct bank",
                        icon = Icons.Rounded.AccountBalance,
                        accentColor = SkySecondary,
                        useMonoFont = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                TabRow(selectedTabIndex = selectedTab) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Transactions (${payments.size})") }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Balances Due (${unpaidOrPartialOrders.size})") }
                    )
                }
            }

            if (selectedTab == 0) {
                item {
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = methodFilter == null,
                            onClick = { methodFilter = null },
                            label = { Text("All Methods") }
                        )
                        PaymentMethod.entries.forEach { m ->
                            FilterChip(
                                selected = methodFilter == m,
                                onClick = { methodFilter = m },
                                label = { Text(m.label) }
                            )
                        }
                    }
                }

                if (filteredPayments.isEmpty()) {
                    item {
                        EmptyStateCard(
                            icon = Icons.Rounded.Payments,
                            title = "No payments recorded yet",
                            subtitle = "Payments recorded on orders via Cash or Bank Transfer appear here automatically."
                        )
                    }
                } else {
                    items(filteredPayments, key = { it.id }) { payment ->
                        PaymentTransactionCard(
                            payment = payment,
                            currencySymbol = currencySymbol,
                            onClick = { onOpenOrder(payment.orderId) }
                        )
                    }
                }
            } else {
                if (unpaidOrPartialOrders.isEmpty()) {
                    item {
                        EmptyStateCard(
                            icon = Icons.Rounded.AccountBalanceWallet,
                            title = "All orders are fully paid",
                            subtitle = "There are no outstanding balances awaiting payment."
                        )
                    }
                } else {
                    items(unpaidOrPartialOrders, key = { it.id }) { ord ->
                        OutstandingOrderCard(
                            order = ord,
                            currencySymbol = currencySymbol,
                            onRecordPayment = { paymentTargetOrder = ord },
                            onOpenOrder = { onOpenOrder(ord.id) }
                        )
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(72.dp)) }
        }
    }

    paymentTargetOrder?.let { target ->
        RecordPaymentDialog(
            order = target,
            currencySymbol = currencySymbol,
            onDismiss = { paymentTargetOrder = null },
            onSubmit = { amount, method, ref, notes ->
                onRecordPayment(target.id, amount, method, ref, notes) {
                    paymentTargetOrder = null
                }
            }
        )
    }
}

@Composable
private fun PaymentTransactionCard(
    payment: PaymentEntity,
    currencySymbol: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.weight(1f)) {
                Column {
                    Text(
                        text = "${payment.orderNumber} • ${payment.customerName}",
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = buildString {
                            append(payment.methodEnum.label)
                            if (payment.reference.isNotBlank()) append(" • Ref: ${payment.reference}")
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = Formatters.formatDateTime(payment.paidAt),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "+${Formatters.formatCurrency(payment.amount, currencySymbol)}",
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMono),
                color = SuccessGreen,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun OutstandingOrderCard(
    order: OrderEntity,
    currencySymbol: String,
    onRecordPayment: () -> Unit,
    onOpenOrder: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenOrder),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(order.orderNumber, style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMono))
                    PaymentStatusBadge(order.paymentStatusEnum)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(order.customerName, style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Balance: ${Formatters.formatCurrency(order.outstandingBalance, currencySymbol)} of ${Formatters.formatCurrency(order.totalAmount, currencySymbol)}",
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMono),
                    color = DangerRed
                )
            }
            Surface(
                color = MaterialTheme.colorScheme.primary,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.clickable(onClick = onRecordPayment)
            ) {
                Text(
                    text = "Pay",
                    color = MaterialTheme.colorScheme.onPrimary,
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }
        }
    }
}
