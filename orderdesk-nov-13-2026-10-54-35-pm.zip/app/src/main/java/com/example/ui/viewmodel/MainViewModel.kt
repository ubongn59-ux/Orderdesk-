package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ActivityEntity
import com.example.data.local.BusinessEntity
import com.example.data.local.CartLineRequest
import com.example.data.local.CustomerEntity
import com.example.data.local.OrderEntity
import com.example.data.local.OrderItemEntity
import com.example.data.local.OrderStatus
import com.example.data.local.PaymentEntity
import com.example.data.local.PaymentMethod
import com.example.data.local.ProductEntity
import com.example.data.local.UserEntity
import com.example.data.repository.OrderDeskRepository
import com.example.ui.theme.ThemeMode
import com.example.util.Formatters
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

data class DailySalesPoint(
    val dayLabel: String,
    val revenue: Double,
    val orderCount: Int
)

data class DashboardSummary(
    val totalSales: Double = 0.0,
    val totalCollected: Double = 0.0,
    val outstandingBalance: Double = 0.0,
    val totalOrders: Int = 0,
    val pendingOrders: Int = 0,
    val totalCustomers: Int = 0,
    val totalProducts: Int = 0,
    val lowStockProducts: List<ProductEntity> = emptyList(),
    val dailySales: List<DailySalesPoint> = emptyList()
)

sealed interface MainUiEvent {
    data class ShowMessage(val message: String) : MainUiEvent
    data class LowStockAlert(val products: List<ProductEntity>) : MainUiEvent
    data class OrderCreated(val orderId: String) : MainUiEvent
}

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(
    private val repository: OrderDeskRepository,
    val userId: String,
    initialBusinessId: String?
) : ViewModel() {

    private val activeBusinessIdFlow = MutableStateFlow(initialBusinessId)

    init {
        viewModelScope.launch {
            repository.sessionFlow.collect { session ->
                if (session.activeBusinessId != null && session.activeBusinessId != activeBusinessIdFlow.value) {
                    activeBusinessIdFlow.value = session.activeBusinessId
                }
            }
        }
    }

    private val _events = MutableSharedFlow<MainUiEvent>()
    val events: SharedFlow<MainUiEvent> = _events.asSharedFlow()

    val currentUser: StateFlow<UserEntity?> = repository.observeUser(userId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val businesses: StateFlow<List<BusinessEntity>> = repository.observeBusinesses(userId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeBusiness: StateFlow<BusinessEntity?> = combine(
        activeBusinessIdFlow,
        businesses
    ) { selectedId, list ->
        list.firstOrNull { it.id == selectedId } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val resolvedBusinessId: Flow<String?> = activeBusiness.let { bizFlow ->
        combine(bizFlow, activeBusinessIdFlow) { biz, id -> biz?.id ?: id }
    }

    val products: StateFlow<List<ProductEntity>> = resolvedBusinessId
        .flatMapLatest { bizId ->
            if (bizId == null) flowOf(emptyList()) else repository.observeProducts(bizId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customers: StateFlow<List<CustomerEntity>> = resolvedBusinessId
        .flatMapLatest { bizId ->
            if (bizId == null) flowOf(emptyList()) else repository.observeCustomers(bizId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<OrderEntity>> = resolvedBusinessId
        .flatMapLatest { bizId ->
            if (bizId == null) flowOf(emptyList()) else repository.observeOrders(bizId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allOrderItems: StateFlow<List<OrderItemEntity>> = resolvedBusinessId
        .flatMapLatest { bizId ->
            if (bizId == null) flowOf(emptyList()) else repository.observeAllOrderItems(bizId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payments: StateFlow<List<PaymentEntity>> = resolvedBusinessId
        .flatMapLatest { bizId ->
            if (bizId == null) flowOf(emptyList()) else repository.observePayments(bizId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activities: StateFlow<List<ActivityEntity>> = resolvedBusinessId
        .flatMapLatest { bizId ->
            if (bizId == null) flowOf(emptyList()) else repository.observeActivities(bizId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dashboardSummary: StateFlow<DashboardSummary> = combine(
        orders,
        customers,
        products,
        payments
    ) { orderList, customerList, productList, paymentList ->
        val activeOrders = orderList.filter { it.statusEnum != OrderStatus.CANCELLED }
        val totalSales = activeOrders.sumOf { it.totalAmount }
        val totalCollected = paymentList.sumOf { it.amount }
        val outstanding = activeOrders.sumOf { it.outstandingBalance }
        val pendingCount = orderList.count { it.statusEnum == OrderStatus.PENDING }
        val lowStock = productList.filter { it.quantity <= it.lowStockThreshold }
            .sortedBy { it.quantity }

        val dailyPoints = buildLast7DaysSales(activeOrders)

        DashboardSummary(
            totalSales = totalSales,
            totalCollected = totalCollected,
            outstandingBalance = outstanding,
            totalOrders = orderList.size,
            pendingOrders = pendingCount,
            totalCustomers = customerList.size,
            totalProducts = productList.size,
            lowStockProducts = lowStock,
            dailySales = dailyPoints
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardSummary())

    fun observeOrderItems(orderId: String): Flow<List<OrderItemEntity>> {
        val bizId = activeBusiness.value?.id ?: activeBusinessIdFlow.value ?: return flowOf(emptyList())
        return repository.observeOrderItems(orderId, bizId)
    }

    fun observePaymentsForOrder(orderId: String): Flow<List<PaymentEntity>> {
        val bizId = activeBusiness.value?.id ?: activeBusinessIdFlow.value ?: return flowOf(emptyList())
        return repository.observePaymentsForOrder(orderId, bizId)
    }

    fun observeOrdersForCustomer(customerId: String): Flow<List<OrderEntity>> {
        val bizId = activeBusiness.value?.id ?: activeBusinessIdFlow.value ?: return flowOf(emptyList())
        return repository.observeOrdersForCustomer(bizId, customerId)
    }

    // --- Product Actions ---
    fun saveProduct(
        existingId: String?,
        name: String,
        sku: String,
        category: String,
        price: Double,
        quantity: Int,
        lowStockThreshold: Int,
        imageUri: String?,
        onSuccess: () -> Unit
    ) {
        val bizId = activeBusiness.value?.id ?: return
        viewModelScope.launch {
            repository.saveProduct(
                businessId = bizId,
                existingId = existingId,
                name = name,
                sku = sku,
                category = category,
                price = price,
                quantity = quantity,
                lowStockThreshold = lowStockThreshold,
                imageUri = imageUri
            ).onSuccess { saved ->
                if (saved.quantity <= saved.lowStockThreshold) {
                    _events.emit(MainUiEvent.LowStockAlert(listOf(saved)))
                }
                _events.emit(MainUiEvent.ShowMessage(if (existingId == null) "Product added" else "Product updated"))
                onSuccess()
            }.onFailure { err ->
                _events.emit(MainUiEvent.ShowMessage(err.message ?: "Failed to save product"))
            }
        }
    }

    fun deleteProduct(productId: String) {
        val bizId = activeBusiness.value?.id ?: return
        viewModelScope.launch {
            repository.deleteProduct(bizId, productId)
            _events.emit(MainUiEvent.ShowMessage("Product deleted"))
        }
    }

    // --- Customer Actions ---
    fun saveCustomer(
        existingId: String?,
        name: String,
        phone: String,
        email: String,
        address: String,
        notes: String,
        onSuccess: (CustomerEntity) -> Unit = {}
    ) {
        val bizId = activeBusiness.value?.id ?: return
        viewModelScope.launch {
            repository.saveCustomer(
                businessId = bizId,
                existingId = existingId,
                name = name,
                phone = phone,
                email = email,
                address = address,
                notes = notes
            ).onSuccess { saved ->
                _events.emit(MainUiEvent.ShowMessage(if (existingId == null) "Customer saved" else "Customer updated"))
                onSuccess(saved)
            }.onFailure { err ->
                _events.emit(MainUiEvent.ShowMessage(err.message ?: "Failed to save customer"))
            }
        }
    }

    fun deleteCustomer(customerId: String) {
        val bizId = activeBusiness.value?.id ?: return
        viewModelScope.launch {
            repository.deleteCustomer(bizId, customerId)
            _events.emit(MainUiEvent.ShowMessage("Customer deleted"))
        }
    }

    // --- Order Actions ---
    fun createOrder(
        customerId: String?,
        customerName: String,
        customerPhone: String,
        customerEmail: String,
        cartLines: List<CartLineRequest>,
        discount: Double,
        initialPaymentAmount: Double,
        initialPaymentMethod: PaymentMethod,
        initialPaymentReference: String,
        notes: String,
        onSuccess: (String) -> Unit
    ) {
        val bizId = activeBusiness.value?.id ?: return
        viewModelScope.launch {
            repository.createOrder(
                businessId = bizId,
                customerId = customerId,
                customerName = customerName,
                customerPhone = customerPhone,
                customerEmail = customerEmail,
                cartLines = cartLines,
                discount = discount,
                initialPaymentAmount = initialPaymentAmount,
                initialPaymentMethod = initialPaymentMethod,
                initialPaymentReference = initialPaymentReference,
                notes = notes
            ).onSuccess { result ->
                _events.emit(MainUiEvent.ShowMessage("Order ${result.order.orderNumber} created"))
                if (result.lowStockTriggeredProducts.isNotEmpty()) {
                    _events.emit(MainUiEvent.LowStockAlert(result.lowStockTriggeredProducts))
                }
                _events.emit(MainUiEvent.OrderCreated(result.order.id))
                onSuccess(result.order.id)
            }.onFailure { err ->
                _events.emit(MainUiEvent.ShowMessage(err.message ?: "Unable to create order"))
            }
        }
    }

    fun updateOrderStatus(orderId: String, newStatus: OrderStatus) {
        val bizId = activeBusiness.value?.id ?: return
        viewModelScope.launch {
            repository.updateOrderStatus(bizId, orderId, newStatus)
                .onSuccess {
                    _events.emit(MainUiEvent.ShowMessage("Order marked ${newStatus.label}"))
                }
                .onFailure { err ->
                    _events.emit(MainUiEvent.ShowMessage(err.message ?: "Failed to update status"))
                }
        }
    }

    fun deleteOrder(orderId: String, onDone: () -> Unit = {}) {
        val bizId = activeBusiness.value?.id ?: return
        viewModelScope.launch {
            repository.deleteOrder(bizId, orderId)
            _events.emit(MainUiEvent.ShowMessage("Order removed"))
            onDone()
        }
    }

    // --- Payment Actions ---
    fun recordPayment(
        orderId: String,
        amount: Double,
        method: PaymentMethod,
        reference: String,
        notes: String,
        onSuccess: () -> Unit = {}
    ) {
        val bizId = activeBusiness.value?.id ?: return
        viewModelScope.launch {
            repository.recordPayment(bizId, orderId, amount, method, reference, notes)
                .onSuccess {
                    _events.emit(MainUiEvent.ShowMessage("Payment recorded"))
                    onSuccess()
                }
                .onFailure { err ->
                    _events.emit(MainUiEvent.ShowMessage(err.message ?: "Failed to record payment"))
                }
        }
    }

    // --- Settings & Multi-Business Actions ---
    fun switchBusiness(businessId: String) {
        activeBusinessIdFlow.value = businessId
        viewModelScope.launch {
            repository.switchBusiness(businessId)
            _events.emit(MainUiEvent.ShowMessage("Switched active business"))
        }
    }

    fun createNewBusiness(
        name: String,
        phone: String,
        address: String,
        currencySymbol: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.createBusiness(userId, name, phone, address, currencySymbol)
                .onSuccess { created ->
                    activeBusinessIdFlow.value = created.id
                    _events.emit(MainUiEvent.ShowMessage("Business '${created.name}' created (${created.businessCode})"))
                    onSuccess()
                }
                .onFailure { err ->
                    _events.emit(MainUiEvent.ShowMessage(err.message ?: "Failed to create business"))
                }
        }
    }

    fun updateBusinessProfile(
        name: String,
        phone: String,
        address: String,
        currencySymbol: String,
        logoUri: String?
    ) {
        val current = activeBusiness.value ?: return
        if (name.trim().length < 2) {
            viewModelScope.launch { _events.emit(MainUiEvent.ShowMessage("Business name cannot be empty")) }
            return
        }
        viewModelScope.launch {
            repository.updateBusiness(
                current.copy(
                    name = name.trim(),
                    phone = phone.trim(),
                    address = address.trim(),
                    currencySymbol = currencySymbol.ifBlank { "₦" },
                    logoUri = logoUri
                )
            )
            _events.emit(MainUiEvent.ShowMessage("Business profile saved"))
        }
    }

    fun updateUserProfile(fullName: String) {
        viewModelScope.launch {
            repository.updateUserProfile(userId, fullName)
                .onSuccess { _events.emit(MainUiEvent.ShowMessage("Profile updated")) }
                .onFailure { err -> _events.emit(MainUiEvent.ShowMessage(err.message ?: "Failed to update profile")) }
        }
    }

    fun changePassword(currentPassword: String, newPassword: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.changePassword(userId, currentPassword, newPassword)
                .onSuccess {
                    _events.emit(MainUiEvent.ShowMessage("Password changed successfully"))
                    onSuccess()
                }
                .onFailure { err ->
                    _events.emit(MainUiEvent.ShowMessage(err.message ?: "Failed to change password"))
                }
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            repository.setThemeMode(mode)
        }
    }

    fun signOut() {
        viewModelScope.launch {
            repository.signOut()
        }
    }

    private fun buildLast7DaysSales(orders: List<OrderEntity>): List<DailySalesPoint> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)

        val dayBuckets = (6 downTo 0).map { daysAgo ->
            val dayStart = (cal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -daysAgo) }.timeInMillis
            val dayEnd = dayStart + 86_400_000L
            val dayOrders = orders.filter { it.createdAt in dayStart until dayEnd }
            DailySalesPoint(
                dayLabel = Formatters.formatShortDay(dayStart),
                revenue = dayOrders.sumOf { it.totalAmount },
                orderCount = dayOrders.size
            )
        }
        return dayBuckets
    }
}
