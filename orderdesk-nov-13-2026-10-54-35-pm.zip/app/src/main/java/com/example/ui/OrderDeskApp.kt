package com.example.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.People
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.local.CustomerEntity
import com.example.ui.screens.BusinessHeaderChip
import com.example.ui.screens.CustomersScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.OrdersScreen
import com.example.ui.screens.PaymentsScreen
import com.example.ui.screens.ProductsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.ThemeMode
import com.example.ui.viewmodel.MainUiEvent
import com.example.ui.viewmodel.MainViewModel
import com.example.util.LowStockNotifier
import kotlinx.coroutines.launch

object OrderDeskRoutes {
    const val DASHBOARD = "dashboard"
    const val ORDERS = "orders"
    const val PRODUCTS = "products"
    const val CUSTOMERS = "customers"
    const val PAYMENTS = "payments"
    const val SETTINGS = "settings"
}

private data class NavDestinationItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private val primaryTabs = listOf(
    NavDestinationItem(OrderDeskRoutes.DASHBOARD, "Home", Icons.Rounded.Dashboard, Icons.Outlined.Dashboard),
    NavDestinationItem(OrderDeskRoutes.ORDERS, "Orders", Icons.Rounded.ShoppingBag, Icons.Outlined.ShoppingBag),
    NavDestinationItem(OrderDeskRoutes.PRODUCTS, "Products", Icons.Rounded.Inventory2, Icons.Outlined.Inventory2),
    NavDestinationItem(OrderDeskRoutes.CUSTOMERS, "Customers", Icons.Rounded.People, Icons.Outlined.People),
    NavDestinationItem(OrderDeskRoutes.PAYMENTS, "Payments", Icons.Rounded.Payments, Icons.Outlined.Payments)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderDeskWorkspace(
    viewModel: MainViewModel,
    themeMode: ThemeMode,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val user by viewModel.currentUser.collectAsStateWithLifecycle()
    val businesses by viewModel.businesses.collectAsStateWithLifecycle()
    val activeBusiness by viewModel.activeBusiness.collectAsStateWithLifecycle()
    val summary by viewModel.dashboardSummary.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()
    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val payments by viewModel.payments.collectAsStateWithLifecycle()
    val activities by viewModel.activities.collectAsStateWithLifecycle()

    var openProductEditor by remember { mutableStateOf(false) }
    var openCustomerEditor by remember { mutableStateOf(false) }
    var openOrderCreator by remember { mutableStateOf(false) }
    var preselectedCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var openOrderDetailId by remember { mutableStateOf<String?>(null) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* Permission result handled gracefully */ }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    LaunchedEffect(viewModel) {
        viewModel.events.collect { event ->
            when (event) {
                is MainUiEvent.ShowMessage -> {
                    snackbarHostState.showSnackbar(event.message)
                }
                is MainUiEvent.LowStockAlert -> {
                    LowStockNotifier.notifyLowStock(context, event.products)
                }
                is MainUiEvent.OrderCreated -> Unit
            }
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: OrderDeskRoutes.DASHBOARD

    fun navigateTab(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    navigationIcon = {
                        if (currentRoute == OrderDeskRoutes.SETTINGS) {
                            IconButton(onClick = { navController.popBackStack() }) {
                                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                            }
                        }
                    },
                    title = {
                        val title = when (currentRoute) {
                            OrderDeskRoutes.DASHBOARD -> "OrderDesk"
                            OrderDeskRoutes.ORDERS -> "Orders"
                            OrderDeskRoutes.PRODUCTS -> "Products"
                            OrderDeskRoutes.CUSTOMERS -> "Customers"
                            OrderDeskRoutes.PAYMENTS -> "Payments"
                            OrderDeskRoutes.SETTINGS -> "Settings"
                            else -> "OrderDesk"
                        }
                        Text(title, style = MaterialTheme.typography.titleLarge)
                    },
                    actions = {
                        if (currentRoute != OrderDeskRoutes.SETTINGS) {
                            BusinessHeaderChip(
                                business = activeBusiness,
                                onClick = { navController.navigate(OrderDeskRoutes.SETTINGS) },
                                modifier = Modifier.padding(end = 6.dp)
                            )
                            IconButton(
                                onClick = { navController.navigate(OrderDeskRoutes.SETTINGS) },
                                modifier = Modifier.testTag("topbar_settings_button")
                            ) {
                                Icon(Icons.Rounded.Settings, contentDescription = "Settings")
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                    }
                )
            },
            bottomBar = {
                if (!useNavRail && currentRoute != OrderDeskRoutes.SETTINGS) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        primaryTabs.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTab(tab.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label, maxLines = 1) },
                                modifier = Modifier.testTag("nav_tab_${tab.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavRail && currentRoute != OrderDeskRoutes.SETTINGS) {
                    NavigationRail(containerColor = MaterialTheme.colorScheme.surface) {
                        primaryTabs.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTab(tab.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag("rail_tab_${tab.route}")
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    NavHost(
                        navController = navController,
                        startDestination = OrderDeskRoutes.DASHBOARD
                    ) {
                        composable(OrderDeskRoutes.DASHBOARD) {
                            DashboardScreen(
                                user = user,
                                business = activeBusiness,
                                summary = summary,
                                activities = activities,
                                onNewOrder = {
                                    preselectedCustomer = null
                                    openOrderCreator = true
                                    navigateTab(OrderDeskRoutes.ORDERS)
                                },
                                onAddProduct = {
                                    openProductEditor = true
                                    navigateTab(OrderDeskRoutes.PRODUCTS)
                                },
                                onAddCustomer = {
                                    openCustomerEditor = true
                                    navigateTab(OrderDeskRoutes.CUSTOMERS)
                                },
                                onNavigateOrders = { navigateTab(OrderDeskRoutes.ORDERS) },
                                onNavigateProducts = { navigateTab(OrderDeskRoutes.PRODUCTS) },
                                onNavigateCustomers = { navigateTab(OrderDeskRoutes.CUSTOMERS) },
                                onNavigatePayments = { navigateTab(OrderDeskRoutes.PAYMENTS) },
                                onOpenSettings = { navController.navigate(OrderDeskRoutes.SETTINGS) }
                            )
                        }
                        composable(OrderDeskRoutes.PRODUCTS) {
                            ProductsScreen(
                                products = products,
                                currencySymbol = activeBusiness?.currencySymbol ?: "₦",
                                openEditorTrigger = openProductEditor,
                                onConsumeEditorTrigger = { openProductEditor = false },
                                onSaveProduct = viewModel::saveProduct,
                                onDeleteProduct = viewModel::deleteProduct
                            )
                        }
                        composable(OrderDeskRoutes.CUSTOMERS) {
                            CustomersScreen(
                                customers = customers,
                                allOrders = orders,
                                currencySymbol = activeBusiness?.currencySymbol ?: "₦",
                                businessName = activeBusiness?.name ?: "OrderDesk",
                                openEditorTrigger = openCustomerEditor,
                                onConsumeEditorTrigger = { openCustomerEditor = false },
                                observeCustomerOrders = viewModel::observeOrdersForCustomer,
                                onSaveCustomer = { id, name, phone, email, addr, notes, onDone ->
                                    viewModel.saveCustomer(id, name, phone, email, addr, notes) {
                                        onDone()
                                    }
                                },
                                onDeleteCustomer = viewModel::deleteCustomer,
                                onCreateOrderForCustomer = { cust ->
                                    preselectedCustomer = cust
                                    openOrderCreator = true
                                    navigateTab(OrderDeskRoutes.ORDERS)
                                }
                            )
                        }
                        composable(OrderDeskRoutes.ORDERS) {
                            OrdersScreen(
                                business = activeBusiness,
                                orders = orders,
                                products = products,
                                customers = customers,
                                openCreateTrigger = openOrderCreator,
                                preselectedCustomerForOrder = preselectedCustomer,
                                openOrderIdTrigger = openOrderDetailId,
                                onConsumeTriggers = {
                                    openOrderCreator = false
                                    preselectedCustomer = null
                                    openOrderDetailId = null
                                },
                                observeOrderItems = viewModel::observeOrderItems,
                                observeOrderPayments = viewModel::observePaymentsForOrder,
                                onCreateOrder = viewModel::createOrder,
                                onUpdateOrderStatus = viewModel::updateOrderStatus,
                                onRecordPayment = viewModel::recordPayment,
                                onDeleteOrder = viewModel::deleteOrder
                            )
                        }
                        composable(OrderDeskRoutes.PAYMENTS) {
                            PaymentsScreen(
                                payments = payments,
                                orders = orders,
                                currencySymbol = activeBusiness?.currencySymbol ?: "₦",
                                onRecordPayment = viewModel::recordPayment,
                                onOpenOrder = { orderId ->
                                    openOrderDetailId = orderId
                                    navigateTab(OrderDeskRoutes.ORDERS)
                                }
                            )
                        }
                        composable(OrderDeskRoutes.SETTINGS) {
                            BackHandler { navController.popBackStack() }
                            SettingsScreen(
                                user = user,
                                activeBusiness = activeBusiness,
                                businesses = businesses,
                                themeMode = themeMode,
                                onSwitchBusiness = viewModel::switchBusiness,
                                onCreateBusiness = viewModel::createNewBusiness,
                                onUpdateBusiness = viewModel::updateBusinessProfile,
                                onUpdateUserProfile = viewModel::updateUserProfile,
                                onChangePassword = viewModel::changePassword,
                                onSetThemeMode = viewModel::setThemeMode,
                                onSignOut = viewModel::signOut,
                                onShowMessage = { msg ->
                                    scope.launch { snackbarHostState.showSnackbar(msg) }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
