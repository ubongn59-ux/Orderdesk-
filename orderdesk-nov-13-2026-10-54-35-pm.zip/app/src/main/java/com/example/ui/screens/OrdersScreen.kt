package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.local.BusinessEntity
import com.example.data.local.CartLineRequest
import com.example.data.local.CustomerEntity
import com.example.data.local.OrderEntity
import com.example.data.local.OrderItemEntity
import com.example.data.local.OrderStatus
import com.example.data.local.PaymentEntity
import com.example.data.local.PaymentMethod
import com.example.data.local.ProductEntity
import com.example.ui.theme.DangerRed
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.WhatsAppGreen
import com.example.util.Formatters
import com.example.util.WhatsAppHelper
import kotlinx.coroutines.flow.Flow

@Composable
fun OrdersScreen(
    business: BusinessEntity?,
    orders: List<OrderEntity>,
    products: List<ProductEntity>,
    customers: List<CustomerEntity>,
    openCreateTrigger: Boolean,
    preselectedCustomerForOrder: CustomerEntity?,
    openOrderIdTrigger: String?,
    onConsumeTriggers: () -> Unit,
    observeOrderItems: (String) -> Flow<List<OrderItemEntity>>,
    observeOrderPayments: (String) -> Flow<List<PaymentEntity>>,
    onCreateOrder: (
        customerId: String?,
        customerName: String,
        customerPhone: String,
        customerEmail: String,
        cartLines: List<CartLineRequest>,
        discount: Double,
        initialPaymentAmount: Double,
        initialPaymentMethod: PaymentMethod,
        initialPaymentReference: String,
        notes: String,
        onSuccess: (String) -> Unit
    ) -> Unit,
    onUpdateOrderStatus: (String, OrderStatus) -> Unit,
    onRecordPayment: (orderId: String, amount: Double, method: PaymentMethod, reference: String, notes: String, onDone: () -> Unit) -> Unit,
    onDeleteOrder: (String, () -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    val sym = business?.currencySymbol ?: "₦"
    var searchQuery by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf<OrderStatus?>(null) }
    var showCreateSheet by remember { mutableStateOf(false) }
    var initialCustomerForSheet by remember { mutableStateOf<CustomerEntity?>(null) }
    var selectedOrderId by remember { mutableStateOf<String?>(null) }

    if (openCreateTrigger) {
        initialCustomerForSheet = preselectedCustomerForOrder
        showCreateSheet = true
        onConsumeTriggers()
    }
    if (openOrderIdTrigger != null) {
        selectedOrderId = openOrderIdTrigger
        onConsumeTriggers()
    }

    val filteredOrders = remember(orders, searchQuery, statusFilter) {
        orders.filter { ord ->
            val matchesQuery = searchQuery.isBlank() ||
                ord.orderNumber.contains(searchQuery, ignoreCase = true) ||
                ord.customerName.contains(searchQuery, ignoreCase = true) ||
                ord.customerPhone.contains(searchQuery, ignoreCase = true)
            val matchesStatus = statusFilter == null || ord.statusEnum == statusFilter
            matchesQuery && matchesStatus
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    initialCustomerForSheet = null
                    showCreateSheet = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("create_order_fab")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Create new order")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search orders by #, customer, or phone") },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    singleLine = true,
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("orders_search_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = statusFilter == null,
                        onClick = { statusFilter = null },
                        label = { Text("All (${orders.size})") }
                    )
                    OrderStatus.entries.forEach { st ->
                        val count = orders.count { it.statusEnum == st }
                        FilterChip(
                            selected = statusFilter == st,
                            onClick = { statusFilter = st },
                            label = { Text("${st.label} ($count)") }
                        )
                    }
                }
            }

            if (filteredOrders.isEmpty()) {
                Box(modifier = Modifier.padding(16.dp)) {
                    EmptyStateCard(
                        icon = Icons.Rounded.ShoppingBag,
                        title = if (orders.isEmpty()) "No orders created yet" else "No matching orders",
                        subtitle = "Create an order with multiple products, automatic stock deduction, receipts, and WhatsApp confirmation.",
                        actionLabel = if (orders.isEmpty()) "Create New Order" else null,
                        onAction = if (orders.isEmpty()) {
                            { initialCustomerForSheet = null; showCreateSheet = true }
                        } else null
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredOrders, key = { it.id }) { order ->
                        OrderCard(
                            order = order,
                            currencySymbol = sym,
                            onClick = { selectedOrderId = order.id }
                        )
                    }
                }
            }
        }
    }

    if (showCreateSheet) {
        CreateOrderSheet(
            products = products,
            customers = customers,
            initialCustomer = initialCustomerForSheet,
            currencySymbol = sym,
            onDismiss = { showCreateSheet = false },
            onSubmit = { custId, name, phone, email, lines, discount, initPay, payMethod, ref, notes ->
                onCreateOrder(custId, name, phone, email, lines, discount, initPay, payMethod, ref, notes) { newId ->
                    showCreateSheet = false
                    selectedOrderId = newId
                }
            }
        )
    }

    val activeOrder = orders.firstOrNull { it.id == selectedOrderId }
    if (activeOrder != null) {
        val items by observeOrderItems(activeOrder.id).collectAsStateWithLifecycle(initialValue = emptyList())
        val orderPayments by observeOrderPayments(activeOrder.id).collectAsStateWithLifecycle(initialValue = emptyList())
        OrderDetailAndReceiptSheet(
            business = business,
            order = activeOrder,
            items = items,
            payments = orderPayments,
            onDismiss = { selectedOrderId = null },
            onUpdateStatus = { status -> onUpdateOrderStatus(activeOrder.id, status) },
            onRecordPayment = { amount, method, ref, notes, onDone ->
                onRecordPayment(activeOrder.id, amount, method, ref, notes, onDone)
            },
            onDelete = {
                onDeleteOrder(activeOrder.id) { selectedOrderId = null }
            }
        )
    }
}

@Composable
private fun OrderCard(
    order: OrderEntity,
    currencySymbol: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("order_card_${order.orderNumber}"),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = order.orderNumber,
                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMono),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = Formatters.formatCurrency(order.totalAmount, currencySymbol),
                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMono),
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = order.customerName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = Formatters.formatDateTime(order.createdAt),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OrderStatusBadge(order.statusEnum)
                    PaymentStatusBadge(order.paymentStatusEnum)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreateOrderSheet(
    products: List<ProductEntity>,
    customers: List<CustomerEntity>,
    initialCustomer: CustomerEntity?,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onSubmit: (
        customerId: String?,
        customerName: String,
        customerPhone: String,
        customerEmail: String,
        cartLines: List<CartLineRequest>,
        discount: Double,
        initialPaymentAmount: Double,
        initialPaymentMethod: PaymentMethod,
        initialPaymentReference: String,
        notes: String
    ) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var selectedCustomer by remember { mutableStateOf(initialCustomer) }
    var customerName by remember { mutableStateOf(initialCustomer?.name ?: "") }
    var customerPhone by remember { mutableStateOf(initialCustomer?.phone ?: "") }
    var customerEmail by remember { mutableStateOf(initialCustomer?.email ?: "") }

    val cartQuantities = remember { mutableStateMapOf<String, Int>() }
    var discountText by remember { mutableStateOf("") }
    var initialPaymentText by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf(PaymentMethod.CASH) }
    var paymentReference by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val subtotal = products.sumOf { prod -> (cartQuantities[prod.id] ?: 0) * prod.price }
    val discount = (discountText.toDoubleOrNull() ?: 0.0).coerceIn(0.0, subtotal)
    val total = (subtotal - discount).coerceAtLeast(0.0)

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Create New Order", style = MaterialTheme.typography.headlineSmall)

            if (error != null) {
                Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(10.dp)) {
                    Text(
                        error!!,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // Saved Customer Quick Picker
            if (customers.isNotEmpty()) {
                Text("Select Saved Customer (Optional)", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedCustomer == null,
                        onClick = { selectedCustomer = null },
                        label = { Text("Walk-in / Manual") }
                    )
                    customers.forEach { cust ->
                        FilterChip(
                            selected = selectedCustomer?.id == cust.id,
                            onClick = {
                                selectedCustomer = cust
                                customerName = cust.name
                                customerPhone = cust.phone
                                customerEmail = cust.email
                            },
                            label = { Text(cust.name) }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = customerName,
                onValueChange = { customerName = it; selectedCustomer = null; error = null },
                label = { Text("Customer Name *") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("order_customer_name_input")
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = customerPhone,
                    onValueChange = { customerPhone = it; error = null },
                    label = { Text("Phone (WhatsApp)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("order_customer_phone_input")
                )
                OutlinedTextField(
                    value = customerEmail,
                    onValueChange = { customerEmail = it },
                    label = { Text("Email (Optional)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.weight(1f)
                )
            }

            HorizontalDivider()
            Text("Add Products", style = MaterialTheme.typography.titleMedium)

            if (products.isEmpty()) {
                Text(
                    "No products available. Add products in the Products tab first.",
                    color = DangerRed,
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                products.forEach { product ->
                    val qty = cartQuantities[product.id] ?: 0
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (qty > 0) {
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            }
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(product.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    "${Formatters.formatCurrency(product.price, currencySymbol)} • ${product.quantity} available",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (product.quantity == 0) DangerRed else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        if (qty > 0) cartQuantities[product.id] = qty - 1
                                    },
                                    enabled = qty > 0,
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(Icons.Rounded.Remove, contentDescription = "Decrease ${product.name}")
                                }
                                Text(
                                    text = qty.toString(),
                                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMono),
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                )
                                IconButton(
                                    onClick = {
                                        if (qty < product.quantity) {
                                            cartQuantities[product.id] = qty + 1
                                            error = null
                                        }
                                    },
                                    enabled = qty < product.quantity,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("add_item_${product.name}")
                                ) {
                                    Icon(Icons.Rounded.Add, contentDescription = "Increase ${product.name}")
                                }
                            }
                        }
                    }
                }
            }

            HorizontalDivider()

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = discountText,
                    onValueChange = { discountText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Discount ($currencySymbol)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = initialPaymentText,
                    onValueChange = { initialPaymentText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Amount Paid ($currencySymbol)") },
                    placeholder = { Text("0 = Unpaid") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("order_initial_payment_input")
                )
            }

            if ((initialPaymentText.toDoubleOrNull() ?: 0.0) > 0.0) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PaymentMethod.entries.forEach { method ->
                        FilterChip(
                            selected = paymentMethod == method,
                            onClick = { paymentMethod = method },
                            label = { Text(method.label) }
                        )
                    }
                }
                OutlinedTextField(
                    value = paymentReference,
                    onValueChange = { paymentReference = it },
                    label = { Text("Payment Reference (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Order Notes (Optional)") },
                modifier = Modifier.fillMaxWidth()
            )

            // Automatic Total Calculation Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Subtotal", style = MaterialTheme.typography.bodyMedium)
                        Text(Formatters.formatCurrency(subtotal, currencySymbol), style = MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMono))
                    }
                    if (discount > 0.0) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Discount", style = MaterialTheme.typography.bodyMedium)
                            Text("-${Formatters.formatCurrency(discount, currencySymbol)}", style = MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMono))
                        }
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total Amount", style = MaterialTheme.typography.titleMedium)
                        Text(
                            Formatters.formatCurrency(total, currencySymbol),
                            style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMono),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Button(
                onClick = {
                    val lines = cartQuantities.entries
                        .filter { it.value > 0 }
                        .map { CartLineRequest(it.key, it.value) }
                    when {
                        customerName.isBlank() -> error = "Please enter customer name."
                        lines.isEmpty() -> error = "Select at least one product to create an order."
                        else -> {
                            val initPay = (initialPaymentText.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
                            onSubmit(
                                selectedCustomer?.id,
                                customerName,
                                customerPhone,
                                customerEmail,
                                lines,
                                discount,
                                initPay,
                                paymentMethod,
                                paymentReference,
                                notes
                            )
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("submit_order_button")
            ) {
                Text("Create Order & Generate Receipt")
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OrderDetailAndReceiptSheet(
    business: BusinessEntity?,
    order: OrderEntity,
    items: List<OrderItemEntity>,
    payments: List<PaymentEntity>,
    onDismiss: () -> Unit,
    onUpdateStatus: (OrderStatus) -> Unit,
    onRecordPayment: (amount: Double, method: PaymentMethod, reference: String, notes: String, onDone: () -> Unit) -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val sym = business?.currencySymbol ?: "₦"
    var showPayDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.ReceiptLong, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Order Receipt", style = MaterialTheme.typography.headlineSmall)
                }
                IconButton(onClick = { showDeleteConfirm = true }) {
                    Icon(Icons.Rounded.Delete, contentDescription = "Delete order", tint = DangerRed)
                }
            }

            // Digital Receipt Card
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            if (!business?.logoUri.isNullOrBlank()) {
                                AsyncImage(
                                    model = business?.logoUri,
                                    contentDescription = "Business logo",
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                            }
                            Column {
                                Text(business?.name ?: "OrderDesk", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    business?.businessCode ?: "",
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMono),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Text(
                            order.orderNumber,
                            style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMono),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    HorizontalDivider()
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Customer", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(order.customerName, style = MaterialTheme.typography.titleSmall)
                            if (order.customerPhone.isNotBlank()) {
                                Text(Formatters.formatNigerianPhone(order.customerPhone), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            OrderStatusBadge(order.statusEnum)
                            Spacer(modifier = Modifier.height(4.dp))
                            PaymentStatusBadge(order.paymentStatusEnum)
                        }
                    }

                    HorizontalDivider()
                    items.forEach { line ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "${line.productName} x${line.quantity}",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                Formatters.formatCurrency(line.lineTotal, sym),
                                style = MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMono)
                            )
                        }
                    }

                    HorizontalDivider()
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total", style = MaterialTheme.typography.titleMedium)
                        Text(
                            Formatters.formatCurrency(order.totalAmount, sym),
                            style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMono)
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Amount Paid", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(Formatters.formatCurrency(order.amountPaid, sym), style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMono))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Balance Due", style = MaterialTheme.typography.titleSmall, color = if (order.outstandingBalance > 0) DangerRed else MaterialTheme.colorScheme.primary)
                        Text(
                            Formatters.formatCurrency(order.outstandingBalance, sym),
                            style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMono),
                            color = if (order.outstandingBalance > 0) DangerRed else MaterialTheme.colorScheme.primary
                        )
                    }
                    Text(
                        "Date: ${Formatters.formatDateTime(order.createdAt)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Order Status Controls
            Text("Track Order Status", style = MaterialTheme.typography.titleSmall)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OrderStatus.entries.forEach { status ->
                    FilterChip(
                        selected = order.statusEnum == status,
                        onClick = { onUpdateStatus(status) },
                        label = { Text(status.label) },
                        leadingIcon = if (order.statusEnum == status) {
                            { Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        } else null
                    )
                }
            }

            // Record Payment Action
            if (order.outstandingBalance > 0.0 && order.statusEnum != OrderStatus.CANCELLED) {
                Button(
                    onClick = { showPayDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("order_record_payment_button")
                ) {
                    Icon(Icons.Rounded.Payments, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Record Payment (${Formatters.formatCurrency(order.outstandingBalance, sym)} due)")
                }
            }

            // WhatsApp & Share Actions
            if (business != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val msg = WhatsAppHelper.buildReceiptText(business, order, items)
                            WhatsAppHelper.sendViaWhatsApp(context, order.customerPhone, msg)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("whatsapp_share_receipt_button")
                    ) {
                        Icon(Icons.Rounded.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("WhatsApp Receipt", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    OutlinedButton(
                        onClick = {
                            val msg = WhatsAppHelper.buildOrderConfirmationText(business, order, items)
                            WhatsAppHelper.sendViaWhatsApp(context, order.customerPhone, msg)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("whatsapp_confirm_order_button")
                    ) {
                        Icon(Icons.Rounded.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Confirm Order", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                OutlinedButton(
                    onClick = {
                        val msg = WhatsAppHelper.buildReceiptText(business, order, items)
                        WhatsAppHelper.sharePlainText(context, msg, "Share Order ${order.orderNumber} Receipt")
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Share Receipt via Other Apps")
                }
            }

            if (payments.isNotEmpty()) {
                HorizontalDivider()
                Text("Payment History (${payments.size})", style = MaterialTheme.typography.titleSmall)
                payments.forEach { p ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${p.methodEnum.label} • ${Formatters.formatDateOnly(p.paidAt)}", style = MaterialTheme.typography.bodySmall)
                        Text(Formatters.formatCurrency(p.amount, sym), style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMono))
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showPayDialog) {
        RecordPaymentDialog(
            order = order,
            currencySymbol = sym,
            onDismiss = { showPayDialog = false },
            onSubmit = { amt, method, ref, note ->
                onRecordPayment(amt, method, ref, note) { showPayDialog = false }
            }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Order ${order.orderNumber}?") },
            text = { Text("Deleting an active order restores its product stock quantities.") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DangerRed)
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun RecordPaymentDialog(
    order: OrderEntity,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onSubmit: (amount: Double, method: PaymentMethod, reference: String, notes: String) -> Unit
) {
    val maxDue = order.outstandingBalance
    var amountText by remember {
        mutableStateOf(if (maxDue % 1.0 == 0.0) maxDue.toLong().toString() else maxDue.toString())
    }
    var method by remember { mutableStateOf(PaymentMethod.CASH) }
    var reference by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Payment") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "${order.orderNumber} • Balance due: ${Formatters.formatCurrency(maxDue, currencySymbol)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (error != null) {
                    Text(error!!, color = DangerRed, style = MaterialTheme.typography.bodySmall)
                }
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' }; error = null },
                    label = { Text("Amount ($currencySymbol)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth().testTag("payment_amount_input")
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PaymentMethod.entries.forEach { m ->
                        FilterChip(
                            selected = method == m,
                            onClick = { method = m },
                            label = { Text(m.label) }
                        )
                    }
                }
                OutlinedTextField(
                    value = reference,
                    onValueChange = { reference = it },
                    label = { Text("Transfer / Receipt Ref (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (amt == null || amt <= 0.0) {
                        error = "Enter a valid payment amount."
                    } else {
                        onSubmit(amt, method, reference, notes)
                    }
                },
                modifier = Modifier.testTag("confirm_record_payment_button")
            ) {
                Text("Save Payment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
