package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.AddShoppingCart
import androidx.compose.material.icons.rounded.Business
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.PendingActions
import androidx.compose.material.icons.rounded.People
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.PostAdd
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.ActivityEntity
import com.example.data.local.ActivityType
import com.example.data.local.BusinessEntity
import com.example.data.local.UserEntity
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.BluePrimaryDark
import com.example.ui.theme.DangerRed
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.SkySecondary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberBg
import com.example.ui.viewmodel.DashboardSummary
import com.example.util.Formatters

@Composable
fun DashboardScreen(
    user: UserEntity?,
    business: BusinessEntity?,
    summary: DashboardSummary,
    activities: List<ActivityEntity>,
    onNewOrder: () -> Unit,
    onAddProduct: () -> Unit,
    onAddCustomer: () -> Unit,
    onNavigateOrders: () -> Unit,
    onNavigateProducts: () -> Unit,
    onNavigateCustomers: () -> Unit,
    onNavigatePayments: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sym = business?.currencySymbol ?: "₦"

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Cobalt Blue Hero Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(BluePrimary, BluePrimaryDark)
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Hello, ${user?.fullName?.split(" ")?.firstOrNull() ?: "Owner"}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                                Text(
                                    text = business?.name ?: "OrderDesk Business",
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "ID: ${business?.businessCode ?: ""}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMono),
                                    color = Color.White.copy(alpha = 0.78f)
                                )
                            }
                            Surface(
                                color = Color.White.copy(alpha = 0.18f),
                                shape = CircleShape,
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .clickable(onClick = onOpenSettings)
                                    .testTag("dashboard_settings_button")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Rounded.Settings,
                                        contentDescription = "Business Settings",
                                        tint = Color.White
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                Text(
                                    text = "Total Sales Revenue",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                                Text(
                                    text = Formatters.formatCurrency(summary.totalSales, sym),
                                    style = MaterialTheme.typography.displaySmall.copy(fontFamily = JetBrainsMono),
                                    color = Color.White
                                )
                            }
                            Surface(
                                color = Color.White.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable(onClick = onNavigatePayments)
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                    Text(
                                        text = "Outstanding",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White.copy(alpha = 0.8f)
                                    )
                                    Text(
                                        text = Formatters.formatCurrency(summary.outstandingBalance, sym),
                                        style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMono),
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Low-Stock Notification Banner
        if (summary.lowStockProducts.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onNavigateProducts)
                        .testTag("low_stock_alert_banner"),
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(
                        containerColor = if (MaterialTheme.colorScheme.background.red < 0.2f) {
                            Color(0xFF3B2809)
                        } else {
                            WarningAmberBg
                        }
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.WarningAmber,
                            contentDescription = "Low stock warning",
                            tint = WarningAmber
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${summary.lowStockProducts.size} product(s) running low on stock",
                                style = MaterialTheme.typography.titleSmall,
                                color = if (MaterialTheme.colorScheme.background.red < 0.2f) Color(0xFFFCD34D) else Color(0xFF78350F)
                            )
                            Text(
                                text = summary.lowStockProducts.take(2).joinToString { "${it.name} (${it.quantity} left)" },
                                style = MaterialTheme.typography.bodySmall,
                                color = if (MaterialTheme.colorScheme.background.red < 0.2f) Color(0xFFFDE68A) else Color(0xFF92400E),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            text = "Restock",
                            style = MaterialTheme.typography.labelLarge,
                            color = WarningAmber
                        )
                    }
                }
            }
        }

        // Quick Actions Strip (Easy one-handed navigation)
        item {
            Column {
                Text(
                    text = "Quick Actions",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionPill(
                        label = "New Order",
                        icon = Icons.Rounded.AddShoppingCart,
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        onClick = onNewOrder,
                        testTag = "quick_new_order"
                    )
                    QuickActionPill(
                        label = "Add Product",
                        icon = Icons.Rounded.PostAdd,
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.primary,
                        onClick = onAddProduct,
                        testTag = "quick_add_product"
                    )
                    QuickActionPill(
                        label = "Add Customer",
                        icon = Icons.Rounded.PersonAdd,
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.primary,
                        onClick = onAddCustomer,
                        testTag = "quick_add_customer"
                    )
                    QuickActionPill(
                        label = "Payments",
                        icon = Icons.Rounded.AccountBalanceWallet,
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.primary,
                        onClick = onNavigatePayments,
                        testTag = "quick_payments"
                    )
                }
            }
        }

        // 2x2 KPI Metrics Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    KpiMetricCard(
                        title = "Total Orders",
                        value = summary.totalOrders.toString(),
                        subtitle = "${summary.pendingOrders} pending",
                        icon = Icons.Rounded.ShoppingBag,
                        accentColor = BluePrimary,
                        modifier = Modifier.weight(1f),
                        useMonoFont = true,
                        onClick = onNavigateOrders
                    )
                    KpiMetricCard(
                        title = "Pending Orders",
                        value = summary.pendingOrders.toString(),
                        subtitle = "Awaiting fulfillment",
                        icon = Icons.Rounded.PendingActions,
                        accentColor = WarningAmber,
                        modifier = Modifier.weight(1f),
                        useMonoFont = true,
                        onClick = onNavigateOrders
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    KpiMetricCard(
                        title = "Customers",
                        value = summary.totalCustomers.toString(),
                        subtitle = "Saved directory",
                        icon = Icons.Rounded.People,
                        accentColor = SkySecondary,
                        modifier = Modifier.weight(1f),
                        useMonoFont = true,
                        onClick = onNavigateCustomers
                    )
                    KpiMetricCard(
                        title = "Products",
                        value = summary.totalProducts.toString(),
                        subtitle = "${summary.lowStockProducts.size} low stock",
                        icon = Icons.Rounded.Inventory2,
                        accentColor = if (summary.lowStockProducts.isNotEmpty()) DangerRed else SuccessGreen,
                        modifier = Modifier.weight(1f),
                        useMonoFont = true,
                        onClick = onNavigateProducts
                    )
                }
            }
        }

        // Sales Statistics Chart
        item {
            SalesBarChartCard(
                points = summary.dailySales,
                currencySymbol = sym
            )
        }

        // Recent Activities Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Activities",
                    style = MaterialTheme.typography.titleMedium
                )
                if (activities.isNotEmpty()) {
                    Text(
                        text = "${activities.size} events",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (activities.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Rounded.TrendingUp,
                    title = "No business activity yet",
                    subtitle = "Add products, register customers, or create orders to see real-time activity updates.",
                    actionLabel = "Add First Product",
                    onAction = onAddProduct
                )
            }
        } else {
            items(activities.take(12), key = { it.id }) { activity ->
                ActivityRowCard(activity)
            }
        }

        item { Spacer(modifier = Modifier.height(12.dp)) }
    }
}

@Composable
private fun QuickActionPill(
    label: String,
    icon: ImageVector,
    containerColor: Color,
    contentColor: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = Modifier
            .height(48.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        color = containerColor,
        shape = RoundedCornerShape(14.dp),
        tonalElevation = 1.dp,
        shadowElevation = 1.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = contentColor,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = contentColor
            )
        }
    }
}

@Composable
private fun ActivityRowCard(activity: ActivityEntity) {
    val (icon, tint) = when (activity.typeEnum) {
        ActivityType.ORDER_CREATED -> Icons.Rounded.ReceiptLong to MaterialTheme.colorScheme.primary
        ActivityType.ORDER_STATUS -> Icons.Rounded.ShoppingBag to SkySecondary
        ActivityType.PAYMENT_RECORDED -> Icons.Rounded.Payments to SuccessGreen
        ActivityType.PRODUCT_ADDED -> Icons.Rounded.Inventory2 to BluePrimary
        ActivityType.PRODUCT_LOW_STOCK -> Icons.Rounded.NotificationsActive to WarningAmber
        ActivityType.CUSTOMER_ADDED -> Icons.Rounded.People to SkySecondary
        ActivityType.BUSINESS_UPDATED -> Icons.Rounded.Business to MaterialTheme.colorScheme.primary
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(tint.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = tint,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = activity.title,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = activity.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = Formatters.formatDateOnly(activity.timestamp),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
