package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.AddBusiness
import androidx.compose.material.icons.rounded.Business
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LockReset
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.BusinessEntity
import com.example.data.local.UserEntity
import com.example.ui.theme.DangerRed
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.ThemeMode
import com.example.util.ImageStorageHelper
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    user: UserEntity?,
    activeBusiness: BusinessEntity?,
    businesses: List<BusinessEntity>,
    themeMode: ThemeMode,
    onSwitchBusiness: (String) -> Unit,
    onCreateBusiness: (name: String, phone: String, address: String, currency: String, onDone: () -> Unit) -> Unit,
    onUpdateBusiness: (name: String, phone: String, address: String, currency: String, logoUri: String?) -> Unit,
    onUpdateUserProfile: (String) -> Unit,
    onChangePassword: (current: String, new: String, onDone: () -> Unit) -> Unit,
    onSetThemeMode: (ThemeMode) -> Unit,
    onSignOut: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var bizName by remember(activeBusiness?.id) { mutableStateOf(activeBusiness?.name ?: "") }
    var bizPhone by remember(activeBusiness?.id) { mutableStateOf(activeBusiness?.phone ?: "") }
    var bizAddress by remember(activeBusiness?.id) { mutableStateOf(activeBusiness?.address ?: "") }
    var bizCurrency by remember(activeBusiness?.id) { mutableStateOf(activeBusiness?.currencySymbol ?: "₦") }
    var bizLogoUri by remember(activeBusiness?.id) { mutableStateOf(activeBusiness?.logoUri) }

    LaunchedEffect(activeBusiness) {
        if (activeBusiness != null) {
            bizName = activeBusiness.name
            bizPhone = activeBusiness.phone
            bizAddress = activeBusiness.address
            bizCurrency = activeBusiness.currencySymbol
            bizLogoUri = activeBusiness.logoUri
        }
    }

    var fullName by remember(user?.id) { mutableStateOf(user?.fullName ?: "") }
    LaunchedEffect(user) {
        if (user != null) fullName = user.fullName
    }

    var showNewBusinessDialog by remember { mutableStateOf(false) }
    var showChangePasswordDialog by remember { mutableStateOf(false) }

    val logoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val persisted = ImageStorageHelper.persistPickedImage(context, uri, "logos")
                if (persisted != null) {
                    bizLogoUri = persisted
                    onUpdateBusiness(bizName, bizPhone, bizAddress, bizCurrency, persisted)
                }
            }
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Multi-Business Switcher Card
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Business, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Registered Businesses (${businesses.size})", style = MaterialTheme.typography.titleMedium)
                        }
                        TextButton(
                            onClick = { showNewBusinessDialog = true },
                            modifier = Modifier.testTag("add_business_button")
                        ) {
                            Icon(Icons.Rounded.AddBusiness, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add New")
                        }
                    }

                    businesses.forEach { biz ->
                        val isActive = biz.id == activeBusiness?.id
                        Surface(
                            color = if (isActive) {
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onSwitchBusiness(biz.id) }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(biz.name, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "${biz.businessCode} • Currency: ${biz.currencySymbol}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMono),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (isActive) {
                                    Icon(
                                        Icons.Rounded.CheckCircle,
                                        contentDescription = "Active business",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Active Business Profile & Logo & Currency
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Business Profile & Currency", style = MaterialTheme.typography.titleMedium)

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer)
                                .clickable {
                                    logoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (!bizLogoUri.isNullOrBlank()) {
                                AsyncImage(
                                    model = bizLogoUri,
                                    contentDescription = "Business logo",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Icon(Icons.Rounded.PhotoCamera, contentDescription = "Pick business logo", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Business ID", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    activeBusiness?.businessCode ?: "",
                                    style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMono)
                                )
                                IconButton(
                                    onClick = {
                                        activeBusiness?.businessCode?.let {
                                            clipboard.setText(AnnotatedString(it))
                                            onShowMessage("Business ID copied")
                                        }
                                    }
                                ) {
                                    Icon(Icons.Rounded.ContentCopy, contentDescription = "Copy Business ID", modifier = Modifier.size(16.dp))
                                }
                            }
                            TextButton(
                                onClick = {
                                    logoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                },
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(if (bizLogoUri == null) "Upload Business Logo" else "Change Business Logo")
                            }
                        }
                    }

                    OutlinedTextField(
                        value = bizName,
                        onValueChange = { bizName = it },
                        label = { Text("Business Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("settings_business_name_input")
                    )
                    OutlinedTextField(
                        value = bizPhone,
                        onValueChange = { bizPhone = it },
                        label = { Text("Business Phone (Nigerian / Intl)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = bizAddress,
                        onValueChange = { bizAddress = it },
                        label = { Text("Business Address") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Currency Symbol", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("₦" to "Naira (₦)", "$" to "USD ($)", "£" to "GBP (£)", "€" to "EUR (€)").forEach { (symbol, label) ->
                            FilterChip(
                                selected = bizCurrency == symbol,
                                onClick = { bizCurrency = symbol },
                                label = { Text(label) }
                            )
                        }
                    }

                    Button(
                        onClick = {
                            onUpdateBusiness(bizName, bizPhone, bizAddress, bizCurrency, bizLogoUri)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_business_settings_button")
                    ) {
                        Text("Save Business Settings")
                    }
                }
            }
        }

        // User Profile & Password Management
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("User Profile & Security", style = MaterialTheme.typography.titleMedium)
                    }
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Full Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = user?.email ?: "",
                        onValueChange = {},
                        enabled = false,
                        label = { Text("Verified Email") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { onUpdateUserProfile(fullName) },
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Text("Save Profile")
                        }
                        OutlinedButton(
                            onClick = { showChangePasswordDialog = true },
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Icon(Icons.Rounded.LockReset, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Password")
                        }
                    }
                }
            }
        }

        // Appearance (Light / Dark Mode)
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.DarkMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Appearance", style = MaterialTheme.typography.titleMedium)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = themeMode == mode,
                                onClick = { onSetThemeMode(mode) },
                                label = { Text(mode.label) }
                            )
                        }
                    }
                }
            }
        }

        // Storage Status Notice (reflecting declined Firebase setup)
        item {
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.CloudOff, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("On-Device Persistence Active", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Firebase cloud setup was skipped, so your businesses, products, orders, customers, and payments are securely saved locally on this device.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Sign Out
        item {
            HorizontalDivider()
            Spacer(modifier = Modifier.height(6.dp))
            Button(
                onClick = onSignOut,
                colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("sign_out_button")
            ) {
                Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sign Out")
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showNewBusinessDialog) {
        var newBizName by remember { mutableStateOf("") }
        var newBizPhone by remember { mutableStateOf("") }
        var newBizAddress by remember { mutableStateOf("") }
        var newBizCurrency by remember { mutableStateOf("₦") }
        AlertDialog(
            onDismissRequest = { showNewBusinessDialog = false },
            title = { Text("Register New Business") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newBizName,
                        onValueChange = { newBizName = it },
                        label = { Text("Business Name *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newBizPhone,
                        onValueChange = { newBizPhone = it },
                        label = { Text("Phone Number") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newBizAddress,
                        onValueChange = { newBizAddress = it },
                        label = { Text("Address") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("₦", "$", "£", "€").forEach { sym ->
                            FilterChip(
                                selected = newBizCurrency == sym,
                                onClick = { newBizCurrency = sym },
                                label = { Text(sym) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCreateBusiness(newBizName, newBizPhone, newBizAddress, newBizCurrency) {
                            showNewBusinessDialog = false
                        }
                    }
                ) { Text("Create Business") }
            },
            dismissButton = {
                TextButton(onClick = { showNewBusinessDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showChangePasswordDialog) {
        var currentPass by remember { mutableStateOf("") }
        var newPass by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showChangePasswordDialog = false },
            title = { Text("Change Password") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = currentPass,
                        onValueChange = { currentPass = it },
                        label = { Text("Current Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newPass,
                        onValueChange = { newPass = it },
                        label = { Text("New Password (min 6 chars)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onChangePassword(currentPass, newPass) {
                            showChangePasswordDialog = false
                        }
                    }
                ) { Text("Update Password") }
            },
            dismissButton = {
                TextButton(onClick = { showChangePasswordDialog = false }) { Text("Cancel") }
            }
        )
    }
}
