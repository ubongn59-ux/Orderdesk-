package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Cobalt Blue & Crisp White Brand Palette
val BluePrimary = Color(0xFF0B509B)
val BluePrimaryDark = Color(0xFF083972)
val BluePrimaryLight = Color(0xFF1976D2)
val BlueContainerLight = Color(0xFFD9E9FF)
val OnBlueContainerLight = Color(0xFF001C3B)

val SkySecondary = Color(0xFF0288D1)
val SkyContainerLight = Color(0xFFCDEEFF)
val OnSkyContainerLight = Color(0xFF002438)

val TealTertiary = Color(0xFF00796B)
val TealContainerLight = Color(0xFFC4F2EA)

// Light Surfaces
val LightBackground = Color(0xFFF5F8FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEAF0F8)
val LightOutline = Color(0xFFC8D4E3)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF475569)

// Dark Surfaces & Blue Accents
val BluePrimaryForDark = Color(0xFF7CB8FF)
val OnBlueForDark = Color(0xFF002F65)
val BlueContainerDark = Color(0xFF0A3D7A)
val OnBlueContainerDark = Color(0xFFD9E9FF)

val SkySecondaryForDark = Color(0xFF64D2FF)
val SkyContainerDark = Color(0xFF004B6B)

val DarkBackground = Color(0xFF0B1220)
val DarkSurface = Color(0xFF111A2B)
val DarkSurfaceVariant = Color(0xFF1B273D)
val DarkOutline = Color(0xFF2D3E5E)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)

// Semantic Status Colors
val SuccessGreen = Color(0xFF15803D)
val SuccessGreenBg = Color(0xFFDCFCE7)
val SuccessGreenDarkBg = Color(0xFF143824)
val SuccessGreenDarkText = Color(0xFF86EFAC)

val WarningAmber = Color(0xFFB45309)
val WarningAmberBg = Color(0xFFFEF3C7)
val WarningAmberDarkBg = Color(0xFF3B2809)
val WarningAmberDarkText = Color(0xFFFCD34D)

val DangerRed = Color(0xFFDC2626)
val DangerRedBg = Color(0xFFFEE2E2)
val DangerRedDarkBg = Color(0xFF451618)
val DangerRedDarkText = Color(0xFFFCA5A5)

val WhatsAppGreen = Color(0xFF16A34A)
