package com.example.util

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

object ImageStorageHelper {

    /**
     * Copies a picked Photo Picker image URI into internal app storage
     * so it remains persistently readable across app restarts.
     */
    suspend fun persistPickedImage(
        context: Context,
        sourceUri: Uri,
        folder: String = "media"
    ): String? = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(context.filesDir, folder).apply { mkdirs() }
            val destFile = File(dir, "img_${UUID.randomUUID()}.jpg")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext null
            destFile.toURI().toString()
        }.getOrNull()
    }
}
