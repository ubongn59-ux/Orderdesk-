package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.data.local.BusinessEntity
import com.example.data.local.OrderEntity
import com.example.data.local.OrderItemEntity
import java.net.URLEncoder

object WhatsAppHelper {

    fun buildReceiptText(
        business: BusinessEntity,
        order: OrderEntity,
        items: List<OrderItemEntity>
    ): String {
        val sym = business.currencySymbol
        val sb = StringBuilder()
        sb.appendLine("*${business.name.uppercase()}*")
        sb.appendLine("Business ID: ${business.businessCode}")
        if (business.phone.isNotBlank()) {
            sb.appendLine("Tel: ${Formatters.formatNigerianPhone(business.phone)}")
        }
        sb.appendLine("--------------------------------")
        sb.appendLine("*OFFICIAL RECEIPT*")
        sb.appendLine("Order #: ${order.orderNumber}")
        sb.appendLine("Date: ${Formatters.formatDateTime(order.createdAt)}")
        sb.appendLine("Customer: ${order.customerName}")
        if (order.customerPhone.isNotBlank()) {
            sb.appendLine("Phone: ${Formatters.formatNigerianPhone(order.customerPhone)}")
        }
        sb.appendLine("--------------------------------")
        items.forEachIndexed { idx, item ->
            sb.appendLine(
                "${idx + 1}. ${item.productName} x${item.quantity} @ ${Formatters.formatCurrency(item.unitPrice, sym)} = ${Formatters.formatCurrency(item.lineTotal, sym)}"
            )
        }
        sb.appendLine("--------------------------------")
        sb.appendLine("Subtotal: ${Formatters.formatCurrency(order.subtotal, sym)}")
        if (order.discount > 0.0) {
            sb.appendLine("Discount: -${Formatters.formatCurrency(order.discount, sym)}")
        }
        sb.appendLine("*Total: ${Formatters.formatCurrency(order.totalAmount, sym)}*")
        sb.appendLine("Paid: ${Formatters.formatCurrency(order.amountPaid, sym)}")
        sb.appendLine("Balance Due: ${Formatters.formatCurrency(order.outstandingBalance, sym)}")
        sb.appendLine("Payment Status: ${order.paymentStatusEnum.label}")
        sb.appendLine("Order Status: ${order.statusEnum.label}")
        sb.appendLine("--------------------------------")
        sb.appendLine("Thank you for your patronage!")
        return sb.toString()
    }

    fun buildOrderConfirmationText(
        business: BusinessEntity,
        order: OrderEntity,
        items: List<OrderItemEntity>
    ): String {
        val sym = business.currencySymbol
        val itemCount = items.sumOf { it.quantity }
        return buildString {
            appendLine("Hello ${order.customerName},")
            appendLine("Your order *${order.orderNumber}* with *${business.name}* has been received ($itemCount items).")
            appendLine("Total: *${Formatters.formatCurrency(order.totalAmount, sym)}*")
            appendLine("Status: ${order.statusEnum.label} | Payment: ${order.paymentStatusEnum.label}")
            if (order.outstandingBalance > 0.0) {
                appendLine("Outstanding Balance: ${Formatters.formatCurrency(order.outstandingBalance, sym)}")
            }
            appendLine("Thank you for choosing ${business.name}!")
        }
    }

    fun sendViaWhatsApp(
        context: Context,
        rawPhone: String,
        message: String
    ) {
        val phoneDigits = Formatters.toWhatsAppInternationalDigits(rawPhone)
        val encoded = URLEncoder.encode(message, "UTF-8")
        val uri = if (phoneDigits.isNotBlank()) {
            Uri.parse("https://wa.me/$phoneDigits?text=$encoded")
        } else {
            Uri.parse("https://wa.me/?text=$encoded")
        }
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to standard share sheet if no WhatsApp/browser handler is available
            sharePlainText(context, message, "Share via WhatsApp")
        }
    }

    fun sharePlainText(
        context: Context,
        message: String,
        chooserTitle: String = "Share Receipt"
    ) {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, message)
        }
        val chooser = Intent.createChooser(sendIntent, chooserTitle).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(chooser)
        } catch (e: Exception) {
            Toast.makeText(context, "Unable to open share dialog", Toast.LENGTH_SHORT).show()
        }
    }
}
