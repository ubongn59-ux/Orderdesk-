package com.example.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.local.ProductEntity

object LowStockNotifier {
    private const val CHANNEL_ID = "orderdesk_low_stock"
    private const val CHANNEL_NAME = "Low Stock Alerts"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications when product inventory drops to or below low-stock threshold"
            }
            manager?.createNotificationChannel(channel)
        }
    }

    fun notifyLowStock(context: Context, products: List<ProductEntity>) {
        if (products.isEmpty()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }
        ensureChannel(context)
        val title = if (products.size == 1) {
            "Low Stock Alert: ${products.first().name}"
        } else {
            "${products.size} Products Running Low"
        }
        val body = if (products.size == 1) {
            val p = products.first()
            "Only ${p.quantity} left in stock (threshold: ${p.lowStockThreshold})."
        } else {
            products.take(3).joinToString(", ") { "${it.name} (${it.quantity})" }
        }
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(
                (System.currentTimeMillis() % 100_000).toInt(),
                notification
            )
        }
    }
}
