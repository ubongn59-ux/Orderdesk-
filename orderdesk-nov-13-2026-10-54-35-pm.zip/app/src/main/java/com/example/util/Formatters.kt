package com.example.util

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Formatters {
    private val numberFormat = DecimalFormat("#,##0.##", DecimalFormatSymbols(Locale.US))
    private val fullCurrencyFormat = DecimalFormat("#,##0.00", DecimalFormatSymbols(Locale.US))
    private val dateTimeFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
    private val dateOnlyFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private val shortDayFormat = SimpleDateFormat("EEE", Locale.getDefault())

    fun formatCurrency(amount: Double, symbol: String = "₦", showDecimals: Boolean = false): String {
        val formatted = if (showDecimals || amount % 1.0 != 0.0) {
            fullCurrencyFormat.format(amount)
        } else {
            numberFormat.format(amount)
        }
        return "$symbol$formatted"
    }

    fun formatDateTime(millis: Long): String = dateTimeFormat.format(Date(millis))

    fun formatDateOnly(millis: Long): String = dateOnlyFormat.format(Date(millis))

    fun formatShortDay(millis: Long): String = shortDayFormat.format(Date(millis))

    /**
     * Converts Nigerian phone inputs (0803..., +234803..., 234803..., 803...)
     * into international WhatsApp-compatible digits (e.g., 2348031234567).
     */
    fun toWhatsAppInternationalDigits(rawPhone: String): String {
        val digitsOnly = rawPhone.filter { it.isDigit() }
        return when {
            digitsOnly.startsWith("234") && digitsOnly.length >= 13 -> digitsOnly
            digitsOnly.startsWith("0") && digitsOnly.length == 11 -> "234" + digitsOnly.substring(1)
            digitsOnly.length == 10 && (digitsOnly.startsWith("7") || digitsOnly.startsWith("8") || digitsOnly.startsWith("9")) ->
                "234$digitsOnly"
            else -> digitsOnly
        }
    }

    /**
     * Formats Nigerian phone numbers nicely for display, e.g., +234 803 123 4567.
     */
    fun formatNigerianPhone(rawPhone: String): String {
        val intl = toWhatsAppInternationalDigits(rawPhone)
        return if (intl.startsWith("234") && intl.length == 13) {
            "+234 ${intl.substring(3, 6)} ${intl.substring(6, 9)} ${intl.substring(9, 13)}"
        } else {
            rawPhone.trim()
        }
    }

    fun isValidNigerianOrIntlPhone(rawPhone: String): Boolean {
        val digits = rawPhone.filter { it.isDigit() }
        return digits.length in 10..15
    }
}
