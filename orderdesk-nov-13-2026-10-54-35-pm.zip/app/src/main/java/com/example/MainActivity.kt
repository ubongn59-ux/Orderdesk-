package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.local.OrderDeskDatabase
import com.example.data.preferences.SessionPreferences
import com.example.data.preferences.SessionState
import com.example.data.repository.OrderDeskRepository
import com.example.ui.OrderDeskWorkspace
import com.example.ui.screens.AuthFlowScreen
import com.example.ui.theme.OrderDeskTheme
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val repository = OrderDeskRepository(
            dao = OrderDeskDatabase.getInstance(applicationContext).orderDeskDao(),
            prefs = SessionPreferences(applicationContext)
        )

        setContent {
            val session by remember { repository.sessionFlow }
                .collectAsStateWithLifecycle(initialValue = SessionState())

            OrderDeskTheme(themeMode = session.themeMode) {
                val activeUserId = session.userId
                if (activeUserId == null) {
                    val authViewModel: AuthViewModel = viewModel(
                        key = "auth_vm",
                        factory = viewModelFactory {
                            initializer { AuthViewModel(repository) }
                        }
                    )
                    AuthFlowScreen(viewModel = authViewModel)
                } else {
                    key(activeUserId) {
                        val mainViewModel: MainViewModel = viewModel(
                            key = activeUserId,
                            factory = viewModelFactory {
                                initializer {
                                    MainViewModel(
                                        repository = repository,
                                        userId = activeUserId,
                                        initialBusinessId = session.activeBusinessId
                                    )
                                }
                            }
                        )
                        OrderDeskWorkspace(
                            viewModel = mainViewModel,
                            themeMode = session.themeMode
                        )
                    }
                }
            }
        }
    }
}
