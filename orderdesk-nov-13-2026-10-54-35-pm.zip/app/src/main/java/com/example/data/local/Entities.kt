package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class OrderStatus(val label: String) {
    PENDING("Pending"),
    PROCESSING("Processing"),
    COMPLETED("Completed"),
    CANCELLED("Cancelled")
}

enum class PaymentStatus(val label: String) {
    UNPAID("Unpaid"),
    PARTIAL("Partially Paid"),
    PAID("Paid")
}

enum class PaymentMethod(val label: String) {
    CASH("Cash"),
    BANK_TRANSFER("Bank Transfer")
}

enum class ActivityType {
    ORDER_CREATED,
    ORDER_STATUS,
    PAYMENT_RECORDED,
    PRODUCT_ADDED,
    PRODUCT_LOW_STOCK,
    CUSTOMER_ADDED,
    BUSINESS_UPDATED
}

@Entity(
    tableName = "users",
    indices = [Index(value = ["email"], unique = true)]
)
data class UserEntity(
    @PrimaryKey val id: String,
    val fullName: String,
    val email: String,
    val passwordHash: String,
    val passwordSalt: String,
    val isVerified: Boolean,
    val pendingOtpCode: String? = null,
    val otpExpiresAt: Long = 0L,
    val resetOtpCode: String? = null,
    val resetOtpExpiresAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "businesses",
    indices = [Index(value = ["ownerUserId"]), Index(value = ["businessCode"], unique = true)]
)
data class BusinessEntity(
    @PrimaryKey val id: String,
    val ownerUserId: String,
    val businessCode: String,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val logoUri: String? = null,
    val currencySymbol: String = "₦",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "products",
    indices = [Index(value = ["businessId"])]
)
data class ProductEntity(
    @PrimaryKey val id: String,
    val businessId: String,
    val name: String,
    val sku: String = "",
    val category: String = "General",
    val price: Double,
    val quantity: Int,
    val lowStockThreshold: Int = 5,
    val imageUri: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "customers",
    indices = [Index(value = ["businessId"])]
)
data class CustomerEntity(
    @PrimaryKey val id: String,
    val businessId: String,
    val name: String,
    val phone: String,
    val email: String = "",
    val address: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "orders",
    indices = [Index(value = ["businessId"]), Index(value = ["customerId"])]
)
data class OrderEntity(
    @PrimaryKey val id: String,
    val businessId: String,
    val orderNumber: String,
    val customerId: String?,
    val customerName: String,
    val customerPhone: String,
    val customerEmail: String = "",
    val subtotal: Double,
    val discount: Double = 0.0,
    val totalAmount: Double,
    val amountPaid: Double = 0.0,
    val orderStatus: String = OrderStatus.PENDING.name,
    val paymentStatus: String = PaymentStatus.UNPAID.name,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val outstandingBalance: Double
        get() = (totalAmount - amountPaid).coerceAtLeast(0.0)

    val statusEnum: OrderStatus
        get() = runCatching { OrderStatus.valueOf(orderStatus) }.getOrDefault(OrderStatus.PENDING)

    val paymentStatusEnum: PaymentStatus
        get() = runCatching { PaymentStatus.valueOf(paymentStatus) }.getOrDefault(PaymentStatus.UNPAID)
}

@Entity(
    tableName = "order_items",
    indices = [Index(value = ["orderId"]), Index(value = ["businessId"])]
)
data class OrderItemEntity(
    @PrimaryKey val id: String,
    val orderId: String,
    val businessId: String,
    val productId: String,
    val productName: String,
    val unitPrice: Double,
    val quantity: Int,
    val lineTotal: Double
)

@Entity(
    tableName = "payments",
    indices = [Index(value = ["businessId"]), Index(value = ["orderId"])]
)
data class PaymentEntity(
    @PrimaryKey val id: String,
    val businessId: String,
    val orderId: String,
    val orderNumber: String,
    val customerName: String,
    val amount: Double,
    val method: String = PaymentMethod.CASH.name,
    val reference: String = "",
    val notes: String = "",
    val paidAt: Long = System.currentTimeMillis()
) {
    val methodEnum: PaymentMethod
        get() = runCatching { PaymentMethod.valueOf(method) }.getOrDefault(PaymentMethod.CASH)
}

@Entity(
    tableName = "activities",
    indices = [Index(value = ["businessId"])]
)
data class ActivityEntity(
    @PrimaryKey val id: String,
    val businessId: String,
    val type: String,
    val title: String,
    val subtitle: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    val typeEnum: ActivityType
        get() = runCatching { ActivityType.valueOf(type) }.getOrDefault(ActivityType.ORDER_CREATED)
}
