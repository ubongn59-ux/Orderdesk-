package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        UserEntity::class,
        BusinessEntity::class,
        ProductEntity::class,
        CustomerEntity::class,
        OrderEntity::class,
        OrderItemEntity::class,
        PaymentEntity::class,
        ActivityEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class OrderDeskDatabase : RoomDatabase() {
    abstract fun orderDeskDao(): OrderDeskDao

    companion object {
        @Volatile
        private var INSTANCE: OrderDeskDatabase? = null

        fun getInstance(context: Context): OrderDeskDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    OrderDeskDatabase::class.java,
                    "orderdesk_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
