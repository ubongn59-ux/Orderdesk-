package com.example.data.security

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object PasswordHasher {
    private val random = SecureRandom()
    private const val ITERATIONS = 12_000
    private const val KEY_LENGTH_BITS = 256

    fun generateSalt(): String {
        val bytes = ByteArray(16)
        random.nextBytes(bytes)
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    fun hashPassword(password: String, saltBase64: String): String {
        val salt = Base64.decode(saltBase64, Base64.NO_WRAP)
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LENGTH_BITS)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val hash = factory.generateSecret(spec).encoded
        return Base64.encodeToString(hash, Base64.NO_WRAP)
    }

    fun verifyPassword(password: String, saltBase64: String, expectedHash: String): Boolean {
        val actual = hashPassword(password, saltBase64)
        return MessageDigest.isEqual(actual.toByteArray(), expectedHash.toByteArray())
    }

    fun generateOtpCode(): String {
        val code = 100_000 + random.nextInt(900_000)
        return code.toString()
    }

    fun generateBusinessCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val part1 = (1..4).map { chars[random.nextInt(chars.length)] }.joinToString("")
        val part2 = (1..4).map { chars[random.nextInt(chars.length)] }.joinToString("")
        return "OD-$part1-$part2"
    }

    fun generateOrderNumber(): String {
        val num = 1000 + random.nextInt(9000)
        val suffix = ('A'..'Z').random()
        return "ORD-$num$suffix"
    }
}
