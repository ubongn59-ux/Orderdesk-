package com.example.data.repository

import com.example.data.local.ActivityEntity
import com.example.data.local.ActivityType
import com.example.data.local.BusinessEntity
import com.example.data.local.CartLineRequest
import com.example.data.local.CustomerEntity
import com.example.data.local.OrderCreationResult
import com.example.data.local.OrderDeskDao
import com.example.data.local.OrderEntity
import com.example.data.local.OrderItemEntity
import com.example.data.local.OrderStatus
import com.example.data.local.PaymentEntity
import com.example.data.local.PaymentMethod
import com.example.data.local.ProductEntity
import com.example.data.local.UserEntity
import com.example.data.preferences.SessionPreferences
import com.example.data.preferences.SessionState
import com.example.data.security.PasswordHasher
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import java.util.UUID

sealed interface AuthResult {
    data class Authenticated(val user: UserEntity, val business: BusinessEntity) : AuthResult
    data class RequiresOtpVerification(val email: String, val otpCode: String) : AuthResult
    data class Error(val message: String) : AuthResult
}

data class ResetOtpDispatchResult(
    val email: String,
    val otpCode: String
)

class OrderDeskRepository(
    private val dao: OrderDeskDao,
    private val prefs: SessionPreferences
) {
    val sessionFlow: Flow<SessionState> = prefs.sessionFlow

    suspend fun setThemeMode(mode: ThemeMode) = prefs.setThemeMode(mode)

    // --- Authentication & Account Lifecycle ---

    suspend fun registerUser(
        fullName: String,
        email: String,
        businessName: String,
        password: String
    ): AuthResult {
        val cleanEmail = email.trim().lowercase()
        val cleanName = fullName.trim()
        val cleanBiz = businessName.trim()

        if (cleanName.length < 2) return AuthResult.Error("Please enter your full name.")
        if (!cleanEmail.contains("@") || !cleanEmail.contains(".")) {
            return AuthResult.Error("Please enter a valid email address.")
        }
        if (cleanBiz.length < 2) return AuthResult.Error("Please enter your business name.")
        if (password.length < 6) return AuthResult.Error("Password must be at least 6 characters.")

        val existing = dao.getUserByEmail(cleanEmail)
        val otp = PasswordHasher.generateOtpCode()
        val expiresAt = System.currentTimeMillis() + 10 * 60 * 1000L

        if (existing != null) {
            if (existing.isVerified) {
                return AuthResult.Error("An account with this email already exists. Please sign in.")
            }
            // Re-issue OTP for unverified registration
            val salt = PasswordHasher.generateSalt()
            val hash = PasswordHasher.hashPassword(password, salt)
            dao.updateUser(
                existing.copy(
                    fullName = cleanName,
                    passwordHash = hash,
                    passwordSalt = salt,
                    pendingOtpCode = otp,
                    otpExpiresAt = expiresAt
                )
            )
            val businesses = dao.getBusinessesForUser(existing.id)
            if (businesses.isNotEmpty()) {
                dao.updateBusiness(businesses.first().copy(name = cleanBiz))
            }
            return AuthResult.RequiresOtpVerification(cleanEmail, otp)
        }

        val userId = UUID.randomUUID().toString()
        val salt = PasswordHasher.generateSalt()
        val hash = PasswordHasher.hashPassword(password, salt)

        val user = UserEntity(
            id = userId,
            fullName = cleanName,
            email = cleanEmail,
            passwordHash = hash,
            passwordSalt = salt,
            isVerified = false,
            pendingOtpCode = otp,
            otpExpiresAt = expiresAt
        )
        dao.insertUser(user)

        val business = BusinessEntity(
            id = UUID.randomUUID().toString(),
            ownerUserId = userId,
            businessCode = PasswordHasher.generateBusinessCode(),
            name = cleanBiz,
            currencySymbol = "₦"
        )
        dao.insertBusiness(business)

        return AuthResult.RequiresOtpVerification(cleanEmail, otp)
    }

    suspend fun resendRegistrationOtp(email: String): Result<String> {
        val cleanEmail = email.trim().lowercase()
        val user = dao.getUserByEmail(cleanEmail)
            ?: return Result.failure(IllegalArgumentException("Account not found."))
        if (user.isVerified) {
            return Result.failure(IllegalStateException("Email is already verified."))
        }
        val otp = PasswordHasher.generateOtpCode()
        dao.updateUser(
            user.copy(
                pendingOtpCode = otp,
                otpExpiresAt = System.currentTimeMillis() + 10 * 60 * 1000L
            )
        )
        return Result.success(otp)
    }

    suspend fun verifyRegistrationOtp(email: String, code: String): AuthResult {
        val cleanEmail = email.trim().lowercase()
        val user = dao.getUserByEmail(cleanEmail)
            ?: return AuthResult.Error("Account not found.")
        if (user.pendingOtpCode == null || user.pendingOtpCode != code.trim()) {
            return AuthResult.Error("Invalid verification code. Please check and try again.")
        }
        if (System.currentTimeMillis() > user.otpExpiresAt) {
            return AuthResult.Error("Verification code expired. Request a new code.")
        }

        val verifiedUser = user.copy(
            isVerified = true,
            pendingOtpCode = null,
            otpExpiresAt = 0L
        )
        dao.updateUser(verifiedUser)

        val business = dao.getBusinessesForUser(verifiedUser.id).firstOrNull()
            ?: BusinessEntity(
                id = UUID.randomUUID().toString(),
                ownerUserId = verifiedUser.id,
                businessCode = PasswordHasher.generateBusinessCode(),
                name = "${verifiedUser.fullName}'s Store"
            ).also { dao.insertBusiness(it) }

        prefs.setSession(verifiedUser.id, business.id)
        return AuthResult.Authenticated(verifiedUser, business)
    }

    suspend fun login(email: String, password: String): AuthResult {
        val cleanEmail = email.trim().lowercase()
        val user = dao.getUserByEmail(cleanEmail)
            ?: return AuthResult.Error("Invalid email or password.")
        if (!PasswordHasher.verifyPassword(password, user.passwordSalt, user.passwordHash)) {
            return AuthResult.Error("Invalid email or password.")
        }
        if (!user.isVerified) {
            val otp = PasswordHasher.generateOtpCode()
            dao.updateUser(
                user.copy(
                    pendingOtpCode = otp,
                    otpExpiresAt = System.currentTimeMillis() + 10 * 60 * 1000L
                )
            )
            return AuthResult.RequiresOtpVerification(cleanEmail, otp)
        }
        val business = dao.getBusinessesForUser(user.id).firstOrNull()
            ?: BusinessEntity(
                id = UUID.randomUUID().toString(),
                ownerUserId = user.id,
                businessCode = PasswordHasher.generateBusinessCode(),
                name = "${user.fullName}'s Business"
            ).also { dao.insertBusiness(it) }

        prefs.setSession(user.id, business.id)
        return AuthResult.Authenticated(user, business)
    }

    suspend fun requestPasswordReset(email: String): Result<ResetOtpDispatchResult> {
        val cleanEmail = email.trim().lowercase()
        val user = dao.getUserByEmail(cleanEmail)
            ?: return Result.failure(IllegalArgumentException("No account found with that email."))
        val otp = PasswordHasher.generateOtpCode()
        dao.updateUser(
            user.copy(
                resetOtpCode = otp,
                resetOtpExpiresAt = System.currentTimeMillis() + 10 * 60 * 1000L
            )
        )
        return Result.success(ResetOtpDispatchResult(cleanEmail, otp))
    }

    suspend fun resetPasswordWithOtp(email: String, otp: String, newPassword: String): Result<Unit> {
        val cleanEmail = email.trim().lowercase()
        if (newPassword.length < 6) {
            return Result.failure(IllegalArgumentException("Password must be at least 6 characters."))
        }
        val user = dao.getUserByEmail(cleanEmail)
            ?: return Result.failure(IllegalArgumentException("Account not found."))
        if (user.resetOtpCode == null || user.resetOtpCode != otp.trim()) {
            return Result.failure(IllegalArgumentException("Invalid reset code."))
        }
        if (System.currentTimeMillis() > user.resetOtpExpiresAt) {
            return Result.failure(IllegalStateException("Reset code expired. Request a new one."))
        }
        val salt = PasswordHasher.generateSalt()
        val hash = PasswordHasher.hashPassword(newPassword, salt)
        dao.updateUser(
            user.copy(
                passwordHash = hash,
                passwordSalt = salt,
                isVerified = true,
                resetOtpCode = null,
                resetOtpExpiresAt = 0L
            )
        )
        return Result.success(Unit)
    }

    suspend fun changePassword(userId: String, currentPass: String, newPass: String): Result<Unit> {
        if (newPass.length < 6) {
            return Result.failure(IllegalArgumentException("New password must be at least 6 characters."))
        }
        val user = dao.getUserById(userId)
            ?: return Result.failure(IllegalStateException("User not found."))
        if (!PasswordHasher.verifyPassword(currentPass, user.passwordSalt, user.passwordHash)) {
            return Result.failure(IllegalArgumentException("Current password is incorrect."))
        }
        val salt = PasswordHasher.generateSalt()
        val hash = PasswordHasher.hashPassword(newPass, salt)
        dao.updateUser(user.copy(passwordHash = hash, passwordSalt = salt))
        return Result.success(Unit)
    }

    suspend fun updateUserProfile(userId: String, fullName: String): Result<Unit> {
        val cleanName = fullName.trim()
        if (cleanName.length < 2) {
            return Result.failure(IllegalArgumentException("Name must be at least 2 characters."))
        }
        val user = dao.getUserById(userId)
            ?: return Result.failure(IllegalStateException("User not found."))
        dao.updateUser(user.copy(fullName = cleanName))
        return Result.success(Unit)
    }

    suspend fun signOut() {
        prefs.clearSession()
    }

    // --- Businesses ---
    fun observeUser(userId: String): Flow<UserEntity?> = dao.observeUser(userId)

    fun observeBusinesses(userId: String): Flow<List<BusinessEntity>> =
        dao.observeBusinessesForUser(userId)

    fun observeBusiness(businessId: String): Flow<BusinessEntity?> =
        dao.observeBusiness(businessId)

    suspend fun switchBusiness(businessId: String) {
        prefs.setActiveBusiness(businessId)
    }

    suspend fun createBusiness(
        ownerUserId: String,
        name: String,
        phone: String,
        address: String,
        currencySymbol: String
    ): Result<BusinessEntity> {
        val cleanName = name.trim()
        if (cleanName.length < 2) {
            return Result.failure(IllegalArgumentException("Business name is required."))
        }
        val business = BusinessEntity(
            id = UUID.randomUUID().toString(),
            ownerUserId = ownerUserId,
            businessCode = PasswordHasher.generateBusinessCode(),
            name = cleanName,
            phone = phone.trim(),
            address = address.trim(),
            currencySymbol = currencySymbol.ifBlank { "₦" }
        )
        dao.insertBusiness(business)
        prefs.setActiveBusiness(business.id)
        return Result.success(business)
    }

    suspend fun updateBusiness(business: BusinessEntity) {
        dao.updateBusiness(business)
        dao.insertActivity(
            ActivityEntity(
                id = UUID.randomUUID().toString(),
                businessId = business.id,
                type = ActivityType.BUSINESS_UPDATED.name,
                title = "Business profile updated",
                subtitle = "${business.name} (${business.currencySymbol})"
            )
        )
    }

    // --- Products ---
    fun observeProducts(businessId: String): Flow<List<ProductEntity>> =
        dao.observeProducts(businessId)

    suspend fun saveProduct(
        businessId: String,
        existingId: String? = null,
        name: String,
        sku: String,
        category: String,
        price: Double,
        quantity: Int,
        lowStockThreshold: Int,
        imageUri: String?
    ): Result<ProductEntity> {
        val cleanName = name.trim()
        if (cleanName.isEmpty()) return Result.failure(IllegalArgumentException("Product name is required."))
        if (price < 0.0) return Result.failure(IllegalArgumentException("Price cannot be negative."))
        if (quantity < 0) return Result.failure(IllegalArgumentException("Quantity cannot be negative."))

        val now = System.currentTimeMillis()
        val existing = existingId?.let { dao.getProductById(it, businessId) }
        val product = ProductEntity(
            id = existing?.id ?: UUID.randomUUID().toString(),
            businessId = businessId,
            name = cleanName,
            sku = sku.trim(),
            category = category.trim().ifBlank { "General" },
            price = price,
            quantity = quantity,
            lowStockThreshold = lowStockThreshold.coerceAtLeast(0),
            imageUri = imageUri,
            createdAt = existing?.createdAt ?: now,
            updatedAt = now
        )
        dao.upsertProduct(product)
        if (existing == null) {
            dao.insertActivity(
                ActivityEntity(
                    id = UUID.randomUUID().toString(),
                    businessId = businessId,
                    type = ActivityType.PRODUCT_ADDED.name,
                    title = "Product added: ${product.name}",
                    subtitle = "Stock: ${product.quantity} units",
                    timestamp = now
                )
            )
        }
        return Result.success(product)
    }

    suspend fun deleteProduct(businessId: String, productId: String) {
        dao.deleteProduct(productId, businessId)
    }

    // --- Customers ---
    fun observeCustomers(businessId: String): Flow<List<CustomerEntity>> =
        dao.observeCustomers(businessId)

    suspend fun saveCustomer(
        businessId: String,
        existingId: String? = null,
        name: String,
        phone: String,
        email: String,
        address: String,
        notes: String
    ): Result<CustomerEntity> {
        val cleanName = name.trim()
        val cleanPhone = phone.trim()
        if (cleanName.isEmpty()) return Result.failure(IllegalArgumentException("Customer name is required."))
        if (cleanPhone.isEmpty()) return Result.failure(IllegalArgumentException("Phone number is required."))

        val existing = existingId?.let { dao.getCustomerById(it, businessId) }
        val customer = CustomerEntity(
            id = existing?.id ?: UUID.randomUUID().toString(),
            businessId = businessId,
            name = cleanName,
            phone = cleanPhone,
            email = email.trim(),
            address = address.trim(),
            notes = notes.trim(),
            createdAt = existing?.createdAt ?: System.currentTimeMillis()
        )
        dao.upsertCustomer(customer)
        if (existing == null) {
            dao.insertActivity(
                ActivityEntity(
                    id = UUID.randomUUID().toString(),
                    businessId = businessId,
                    type = ActivityType.CUSTOMER_ADDED.name,
                    title = "Customer added: ${customer.name}",
                    subtitle = customer.phone
                )
            )
        }
        return Result.success(customer)
    }

    suspend fun deleteCustomer(businessId: String, customerId: String) {
        dao.deleteCustomer(customerId, businessId)
    }

    // --- Orders & Order Items ---
    fun observeOrders(businessId: String): Flow<List<OrderEntity>> =
        dao.observeOrders(businessId)

    fun observeOrdersForCustomer(businessId: String, customerId: String): Flow<List<OrderEntity>> =
        dao.observeOrdersForCustomer(businessId, customerId)

    fun observeOrderItems(orderId: String, businessId: String): Flow<List<OrderItemEntity>> =
        dao.observeOrderItems(orderId, businessId)

    fun observeAllOrderItems(businessId: String): Flow<List<OrderItemEntity>> =
        dao.observeAllOrderItems(businessId)

    suspend fun createOrder(
        businessId: String,
        customerId: String?,
        customerName: String,
        customerPhone: String,
        customerEmail: String,
        cartLines: List<CartLineRequest>,
        discount: Double,
        initialPaymentAmount: Double,
        initialPaymentMethod: PaymentMethod,
        initialPaymentReference: String,
        notes: String
    ): Result<OrderCreationResult> {
        return try {
            val cleanName = customerName.trim().ifBlank { "Walk-in Customer" }
            val result = dao.createOrderTransaction(
                businessId = businessId,
                orderNumber = PasswordHasher.generateOrderNumber(),
                customerId = customerId,
                customerName = cleanName,
                customerPhone = customerPhone.trim(),
                customerEmail = customerEmail.trim(),
                cartLines = cartLines,
                discount = discount,
                initialPaymentAmount = initialPaymentAmount,
                initialPaymentMethod = initialPaymentMethod,
                initialPaymentReference = initialPaymentReference.trim(),
                notes = notes.trim()
            )
            Result.success(result)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateOrderStatus(
        businessId: String,
        orderId: String,
        newStatus: OrderStatus
    ): Result<OrderEntity> {
        return try {
            Result.success(dao.updateOrderStatusTransaction(businessId, orderId, newStatus))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteOrder(businessId: String, orderId: String) {
        dao.deleteOrderTransaction(businessId, orderId)
    }

    // --- Payments ---
    fun observePayments(businessId: String): Flow<List<PaymentEntity>> =
        dao.observePayments(businessId)

    fun observePaymentsForOrder(orderId: String, businessId: String): Flow<List<PaymentEntity>> =
        dao.observePaymentsForOrder(orderId, businessId)

    suspend fun recordPayment(
        businessId: String,
        orderId: String,
        amount: Double,
        method: PaymentMethod,
        reference: String,
        notes: String
    ): Result<OrderEntity> {
        return try {
            Result.success(
                dao.recordPaymentTransaction(
                    businessId = businessId,
                    orderId = orderId,
                    amount = amount,
                    method = method,
                    reference = reference.trim(),
                    notes = notes.trim()
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- Activities ---
    fun observeActivities(businessId: String): Flow<List<ActivityEntity>> =
        dao.observeActivities(businessId)
}
