package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "orderdesk_session")

data class SessionState(
    val userId: String? = null,
    val activeBusinessId: String? = null,
    val themeMode: ThemeMode = ThemeMode.SYSTEM
)

class SessionPreferences(private val context: Context) {

    private object Keys {
        val USER_ID = stringPreferencesKey("logged_in_user_id")
        val ACTIVE_BUSINESS_ID = stringPreferencesKey("active_business_id")
        val THEME_MODE = stringPreferencesKey("theme_mode")
    }

    val sessionFlow: Flow<SessionState> = context.dataStore.data.map { prefs ->
        val modeName = prefs[Keys.THEME_MODE] ?: ThemeMode.SYSTEM.name
        val themeMode = runCatching { ThemeMode.valueOf(modeName) }.getOrDefault(ThemeMode.SYSTEM)
        SessionState(
            userId = prefs[Keys.USER_ID],
            activeBusinessId = prefs[Keys.ACTIVE_BUSINESS_ID],
            themeMode = themeMode
        )
    }

    suspend fun setSession(userId: String, businessId: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.USER_ID] = userId
            prefs[Keys.ACTIVE_BUSINESS_ID] = businessId
        }
    }

    suspend fun setActiveBusiness(businessId: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.ACTIVE_BUSINESS_ID] = businessId
        }
    }

    suspend fun setThemeMode(themeMode: ThemeMode) {
        context.dataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = themeMode.name
        }
    }

    suspend fun clearSession() {
        context.dataStore.edit { prefs ->
            prefs.remove(Keys.USER_ID)
            prefs.remove(Keys.ACTIVE_BUSINESS_ID)
        }
    }
}
