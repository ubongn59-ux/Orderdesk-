package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import java.util.UUID

data class CartLineRequest(
    val productId: String,
    val quantity: Int
)

data class OrderCreationResult(
    val order: OrderEntity,
    val items: List<OrderItemEntity>,
    val lowStockTriggeredProducts: List<ProductEntity>
)

@Dao
interface OrderDeskDao {
    // --- Users ---
    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    suspend fun getUserById(userId: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    fun observeUser(userId: String): Flow<UserEntity?>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)

    // --- Businesses ---
    @Query("SELECT * FROM businesses WHERE ownerUserId = :userId ORDER BY createdAt ASC")
    fun observeBusinessesForUser(userId: String): Flow<List<BusinessEntity>>

    @Query("SELECT * FROM businesses WHERE ownerUserId = :userId ORDER BY createdAt ASC")
    suspend fun getBusinessesForUser(userId: String): List<BusinessEntity>

    @Query("SELECT * FROM businesses WHERE id = :businessId LIMIT 1")
    fun observeBusiness(businessId: String): Flow<BusinessEntity?>

    @Query("SELECT * FROM businesses WHERE id = :businessId LIMIT 1")
    suspend fun getBusinessById(businessId: String): BusinessEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertBusiness(business: BusinessEntity)

    @Update
    suspend fun updateBusiness(business: BusinessEntity)

    // --- Products ---
    @Query("SELECT * FROM products WHERE businessId = :businessId ORDER BY updatedAt DESC")
    fun observeProducts(businessId: String): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE id = :productId AND businessId = :businessId LIMIT 1")
    suspend fun getProductById(productId: String, businessId: String): ProductEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProduct(product: ProductEntity)

    @Query("DELETE FROM products WHERE id = :productId AND businessId = :businessId")
    suspend fun deleteProduct(productId: String, businessId: String)

    // --- Customers ---
    @Query("SELECT * FROM customers WHERE businessId = :businessId ORDER BY name ASC")
    fun observeCustomers(businessId: String): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE id = :customerId AND businessId = :businessId LIMIT 1")
    suspend fun getCustomerById(customerId: String, businessId: String): CustomerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCustomer(customer: CustomerEntity)

    @Query("DELETE FROM customers WHERE id = :customerId AND businessId = :businessId")
    suspend fun deleteCustomer(customerId: String, businessId: String)

    // --- Orders & Items ---
    @Query("SELECT * FROM orders WHERE businessId = :businessId ORDER BY createdAt DESC")
    fun observeOrders(businessId: String): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE id = :orderId AND businessId = :businessId LIMIT 1")
    suspend fun getOrderById(orderId: String, businessId: String): OrderEntity?

    @Query("SELECT * FROM orders WHERE businessId = :businessId AND customerId = :customerId ORDER BY createdAt DESC")
    fun observeOrdersForCustomer(businessId: String, customerId: String): Flow<List<OrderEntity>>

    @Query("SELECT * FROM order_items WHERE orderId = :orderId AND businessId = :businessId")
    fun observeOrderItems(orderId: String, businessId: String): Flow<List<OrderItemEntity>>

    @Query("SELECT * FROM order_items WHERE orderId = :orderId AND businessId = :businessId")
    suspend fun getOrderItems(orderId: String, businessId: String): List<OrderItemEntity>

    @Query("SELECT * FROM order_items WHERE businessId = :businessId")
    fun observeAllOrderItems(businessId: String): Flow<List<OrderItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)

    @Update
    suspend fun updateOrder(order: OrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrderItems(items: List<OrderItemEntity>)

    @Query("DELETE FROM order_items WHERE orderId = :orderId AND businessId = :businessId")
    suspend fun deleteOrderItems(orderId: String, businessId: String)

    @Query("DELETE FROM orders WHERE id = :orderId AND businessId = :businessId")
    suspend fun deleteOrderRow(orderId: String, businessId: String)

    // --- Payments ---
    @Query("SELECT * FROM payments WHERE businessId = :businessId ORDER BY paidAt DESC")
    fun observePayments(businessId: String): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM payments WHERE orderId = :orderId AND businessId = :businessId ORDER BY paidAt DESC")
    fun observePaymentsForOrder(orderId: String, businessId: String): Flow<List<PaymentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: PaymentEntity)

    @Query("DELETE FROM payments WHERE orderId = :orderId AND businessId = :businessId")
    suspend fun deletePaymentsForOrder(orderId: String, businessId: String)

    // --- Activities ---
    @Query("SELECT * FROM activities WHERE businessId = :businessId ORDER BY timestamp DESC LIMIT 40")
    fun observeActivities(businessId: String): Flow<List<ActivityEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivity(activity: ActivityEntity)

    // --- Atomic Business Transactions ---
    @Transaction
    suspend fun createOrderTransaction(
        businessId: String,
        orderNumber: String,
        customerId: String?,
        customerName: String,
        customerPhone: String,
        customerEmail: String,
        cartLines: List<CartLineRequest>,
        discount: Double,
        initialPaymentAmount: Double,
        initialPaymentMethod: PaymentMethod,
        initialPaymentReference: String,
        notes: String
    ): OrderCreationResult {
        require(cartLines.isNotEmpty()) { "Order must include at least one product." }
        val now = System.currentTimeMillis()
        val orderId = UUID.randomUUID().toString()
        val resolvedItems = mutableListOf<OrderItemEntity>()
        val lowStockProducts = mutableListOf<ProductEntity>()
        var subtotal = 0.0

        for (line in cartLines) {
            require(line.quantity > 0) { "Quantity must be greater than zero." }
            val product = getProductById(line.productId, businessId)
                ?: throw IllegalStateException("Selected product no longer exists.")
            if (product.quantity < line.quantity) {
                throw IllegalStateException("Insufficient stock for ${product.name} (${product.quantity} left).")
            }
            val newQty = product.quantity - line.quantity
            val updatedProduct = product.copy(quantity = newQty, updatedAt = now)
            upsertProduct(updatedProduct)
            if (newQty <= product.lowStockThreshold) {
                lowStockProducts.add(updatedProduct)
            }
            val lineTotal = product.price * line.quantity
            subtotal += lineTotal
            resolvedItems.add(
                OrderItemEntity(
                    id = UUID.randomUUID().toString(),
                    orderId = orderId,
                    businessId = businessId,
                    productId = product.id,
                    productName = product.name,
                    unitPrice = product.price,
                    quantity = line.quantity,
                    lineTotal = lineTotal
                )
            )
        }

        val cleanDiscount = discount.coerceIn(0.0, subtotal)
        val totalAmount = (subtotal - cleanDiscount).coerceAtLeast(0.0)
        val paid = initialPaymentAmount.coerceIn(0.0, totalAmount)
        val paymentStatus = when {
            paid <= 0.0 && totalAmount > 0.0 -> PaymentStatus.UNPAID
            paid + 0.009 >= totalAmount -> PaymentStatus.PAID
            else -> PaymentStatus.PARTIAL
        }

        val order = OrderEntity(
            id = orderId,
            businessId = businessId,
            orderNumber = orderNumber,
            customerId = customerId,
            customerName = customerName,
            customerPhone = customerPhone,
            customerEmail = customerEmail,
            subtotal = subtotal,
            discount = cleanDiscount,
            totalAmount = totalAmount,
            amountPaid = paid,
            orderStatus = OrderStatus.PENDING.name,
            paymentStatus = paymentStatus.name,
            notes = notes,
            createdAt = now,
            updatedAt = now
        )
        insertOrder(order)
        insertOrderItems(resolvedItems)

        if (paid > 0.0) {
            insertPayment(
                PaymentEntity(
                    id = UUID.randomUUID().toString(),
                    businessId = businessId,
                    orderId = orderId,
                    orderNumber = orderNumber,
                    customerName = customerName,
                    amount = paid,
                    method = initialPaymentMethod.name,
                    reference = initialPaymentReference,
                    notes = "Initial order payment",
                    paidAt = now
                )
            )
        }

        insertActivity(
            ActivityEntity(
                id = UUID.randomUUID().toString(),
                businessId = businessId,
                type = ActivityType.ORDER_CREATED.name,
                title = "Order $orderNumber created",
                subtitle = "$customerName • ${resolvedItems.sumOf { it.quantity }} items",
                timestamp = now
            )
        )

        for (lowProd in lowStockProducts) {
            insertActivity(
                ActivityEntity(
                    id = UUID.randomUUID().toString(),
                    businessId = businessId,
                    type = ActivityType.PRODUCT_LOW_STOCK.name,
                    title = "Low stock: ${lowProd.name}",
                    subtitle = "${lowProd.quantity} remaining (threshold ${lowProd.lowStockThreshold})",
                    timestamp = now + 1
                )
            )
        }

        return OrderCreationResult(
            order = order,
            items = resolvedItems,
            lowStockTriggeredProducts = lowStockProducts
        )
    }

    @Transaction
    suspend fun recordPaymentTransaction(
        businessId: String,
        orderId: String,
        amount: Double,
        method: PaymentMethod,
        reference: String,
        notes: String
    ): OrderEntity {
        require(amount > 0.0) { "Payment amount must be greater than zero." }
        val order = getOrderById(orderId, businessId)
            ?: throw IllegalStateException("Order not found.")
        val remaining = order.outstandingBalance
        require(remaining > 0.0) { "Order is already fully paid." }
        val appliedAmount = amount.coerceAtMost(remaining)
        val newPaid = order.amountPaid + appliedAmount
        val newStatus = when {
            newPaid + 0.009 >= order.totalAmount -> PaymentStatus.PAID
            newPaid > 0.0 -> PaymentStatus.PARTIAL
            else -> PaymentStatus.UNPAID
        }
        val now = System.currentTimeMillis()
        val updatedOrder = order.copy(
            amountPaid = newPaid,
            paymentStatus = newStatus.name,
            updatedAt = now
        )
        updateOrder(updatedOrder)
        insertPayment(
            PaymentEntity(
                id = UUID.randomUUID().toString(),
                businessId = businessId,
                orderId = order.id,
                orderNumber = order.orderNumber,
                customerName = order.customerName,
                amount = appliedAmount,
                method = method.name,
                reference = reference,
                notes = notes,
                paidAt = now
            )
        )
        insertActivity(
            ActivityEntity(
                id = UUID.randomUUID().toString(),
                businessId = businessId,
                type = ActivityType.PAYMENT_RECORDED.name,
                title = "Payment recorded (${method.label})",
                subtitle = "${order.orderNumber} • ${order.customerName}",
                timestamp = now
            )
        )
        return updatedOrder
    }

    @Transaction
    suspend fun updateOrderStatusTransaction(
        businessId: String,
        orderId: String,
        newStatus: OrderStatus
    ): OrderEntity {
        val order = getOrderById(orderId, businessId)
            ?: throw IllegalStateException("Order not found.")
        val oldStatus = order.statusEnum
        if (oldStatus == newStatus) return order
        val now = System.currentTimeMillis()

        // Restore inventory when cancelling an active order; deduct again if un-cancelling
        if (oldStatus != OrderStatus.CANCELLED && newStatus == OrderStatus.CANCELLED) {
            val items = getOrderItems(orderId, businessId)
            for (item in items) {
                val prod = getProductById(item.productId, businessId)
                if (prod != null) {
                    upsertProduct(prod.copy(quantity = prod.quantity + item.quantity, updatedAt = now))
                }
            }
        } else if (oldStatus == OrderStatus.CANCELLED && newStatus != OrderStatus.CANCELLED) {
            val items = getOrderItems(orderId, businessId)
            for (item in items) {
                val prod = getProductById(item.productId, businessId)
                    ?: throw IllegalStateException("${item.productName} no longer exists.")
                if (prod.quantity < item.quantity) {
                    throw IllegalStateException("Insufficient stock to reactivate order for ${prod.name}.")
                }
                upsertProduct(prod.copy(quantity = prod.quantity - item.quantity, updatedAt = now))
            }
        }

        val updated = order.copy(orderStatus = newStatus.name, updatedAt = now)
        updateOrder(updated)
        insertActivity(
            ActivityEntity(
                id = UUID.randomUUID().toString(),
                businessId = businessId,
                type = ActivityType.ORDER_STATUS.name,
                title = "Order ${order.orderNumber} -> ${newStatus.label}",
                subtitle = order.customerName,
                timestamp = now
            )
        )
        return updated
    }

    @Transaction
    suspend fun deleteOrderTransaction(businessId: String, orderId: String) {
        val order = getOrderById(orderId, businessId) ?: return
        val now = System.currentTimeMillis()
        if (order.statusEnum != OrderStatus.CANCELLED) {
            val items = getOrderItems(orderId, businessId)
            for (item in items) {
                val prod = getProductById(item.productId, businessId)
                if (prod != null) {
                    upsertProduct(prod.copy(quantity = prod.quantity + item.quantity, updatedAt = now))
                }
            }
        }
        deletePaymentsForOrder(orderId, businessId)
        deleteOrderItems(orderId, businessId)
        deleteOrderRow(orderId, businessId)
    }
}
