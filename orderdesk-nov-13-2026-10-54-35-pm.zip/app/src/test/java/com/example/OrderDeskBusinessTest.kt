package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.CartLineRequest
import com.example.data.local.OrderDeskDatabase
import com.example.data.local.OrderStatus
import com.example.data.local.PaymentMethod
import com.example.data.local.PaymentStatus
import com.example.data.preferences.SessionPreferences
import com.example.data.repository.AuthResult
import com.example.data.repository.OrderDeskRepository
import com.example.util.Formatters
import com.example.util.WhatsAppHelper
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class OrderDeskBusinessTest {

    private lateinit var db: OrderDeskDatabase
    private lateinit var repo: OrderDeskRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, OrderDeskDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repo = OrderDeskRepository(db.orderDeskDao(), SessionPreferences(context))
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun `registration requires OTP verification and supports login and password reset`() = runBlocking {
        val regResult = repo.registerUser("Ada Obi", "ada@lagos.ng", "Ada Fabrics", "secret123")
        assertTrue(regResult is AuthResult.RequiresOtpVerification)
        val otp = (regResult as AuthResult.RequiresOtpVerification).otpCode

        // Wrong OTP fails
        val badOtp = repo.verifyRegistrationOtp("ada@lagos.ng", "000000")
        assertTrue(badOtp is AuthResult.Error)

        // Correct OTP authenticates and creates unique business
        val goodOtp = repo.verifyRegistrationOtp("ada@lagos.ng", otp)
        assertTrue(goodOtp is AuthResult.Authenticated)
        val auth = goodOtp as AuthResult.Authenticated
        assertEquals("Ada Fabrics", auth.business.name)
        assertEquals("₦", auth.business.currencySymbol)
        assertTrue(auth.business.businessCode.startsWith("OD-"))

        // Password reset flow
        val resetDispatch = repo.requestPasswordReset("ada@lagos.ng").getOrThrow()
        repo.resetPasswordWithOtp("ada@lagos.ng", resetDispatch.otpCode, "newpass456").getOrThrow()

        // Old password fails, new password succeeds
        assertTrue(repo.login("ada@lagos.ng", "secret123") is AuthResult.Error)
        assertTrue(repo.login("ada@lagos.ng", "newpass456") is AuthResult.Authenticated)
    }

    @Test
    fun `order creation tracks inventory, triggers low stock, calculates partial payments, and isolates businesses`() = runBlocking {
        val reg = repo.registerUser("Chidi", "chidi@shop.ng", "Chidi Electronics", "pass1234") as AuthResult.RequiresOtpVerification
        val auth = repo.verifyRegistrationOtp("chidi@shop.ng", reg.otpCode) as AuthResult.Authenticated
        val biz1 = auth.business

        // Create second isolated business
        val biz2 = repo.createBusiness(auth.user.id, "Chidi Wholesale", "08031234567", "Lagos", "₦").getOrThrow()

        val p1 = repo.saveProduct(
            businessId = biz1.id,
            name = "Inverter Battery",
            sku = "INV-01",
            category = "Power",
            price = 150_000.0,
            quantity = 10,
            lowStockThreshold = 4,
            imageUri = null
        ).getOrThrow()

        val cust = repo.saveCustomer(
            businessId = biz1.id,
            name = "Tunde Bakare",
            phone = "08031234567",
            email = "tunde@mail.com",
            address = "Ikeja, Lagos",
            notes = ""
        ).getOrThrow()

        // Create order for 7 units -> remaining 3 (triggers low stock threshold <= 4)
        val orderResult = repo.createOrder(
            businessId = biz1.id,
            customerId = cust.id,
            customerName = cust.name,
            customerPhone = cust.phone,
            customerEmail = cust.email,
            cartLines = listOf(CartLineRequest(p1.id, 7)),
            discount = 50_000.0,
            initialPaymentAmount = 400_000.0,
            initialPaymentMethod = PaymentMethod.BANK_TRANSFER,
            initialPaymentReference = "GTB-9921",
            notes = "Deliver tomorrow"
        ).getOrThrow()

        assertEquals(1_050_000.0, orderResult.order.subtotal, 0.01)
        assertEquals(1_000_000.0, orderResult.order.totalAmount, 0.01)
        assertEquals(400_000.0, orderResult.order.amountPaid, 0.01)
        assertEquals(600_000.0, orderResult.order.outstandingBalance, 0.01)
        assertEquals(PaymentStatus.PARTIAL, orderResult.order.paymentStatusEnum)
        assertEquals(1, orderResult.lowStockTriggeredProducts.size)
        assertEquals(3, orderResult.lowStockTriggeredProducts.first().quantity)

        // Verify business 2 has zero products and zero orders (strict isolation)
        assertEquals(0, repo.observeProducts(biz2.id).first().size)
        assertEquals(0, repo.observeOrders(biz2.id).first().size)

        // Record remaining balance via Cash -> becomes PAID
        val paidOrder = repo.recordPayment(
            businessId = biz1.id,
            orderId = orderResult.order.id,
            amount = 600_000.0,
            method = PaymentMethod.CASH,
            reference = "",
            notes = "Final settlement"
        ).getOrThrow()
        assertEquals(PaymentStatus.PAID, paidOrder.paymentStatusEnum)
        assertEquals(0.0, paidOrder.outstandingBalance, 0.01)

        // Cancelling order restores stock back to 10
        repo.updateOrderStatus(biz1.id, paidOrder.id, OrderStatus.CANCELLED).getOrThrow()
        val restored = repo.observeProducts(biz1.id).first().first { it.id == p1.id }
        assertEquals(10, restored.quantity)

        // Receipt & Nigerian phone formatting check
        assertEquals("2348031234567", Formatters.toWhatsAppInternationalDigits("08031234567"))
        assertEquals("+234 803 123 4567", Formatters.formatNigerianPhone("08031234567"))
        val receiptText = WhatsAppHelper.buildReceiptText(biz1, paidOrder, orderResult.items)
        assertTrue(receiptText.contains("OFFICIAL RECEIPT"))
        assertTrue(receiptText.contains("Inverter Battery"))
        assertTrue(receiptText.contains("₦"))
    }
}
